# -*- coding: utf-8 -*-
"""
BEBE Task Recorder — Version 5.4
- Scheduler funcțional (days + time interval)
- Playback/Record cu hotkeys globale (ESC stop, F1 rec on/off, F9 play/stop, F10 pause)
- Mini Mode (fereastră mică cu 4 butoane)
- Events list: selectare multi (Ctrl/Shift), Delete, Duplicate, Scale Timestamps, Context Menu
- Logs window
- Fundal mov foarte deschis pentru aplicație
"""

import json
import os
import queue
import threading
import time
import subprocess
from dataclasses import dataclass, asdict, field
from typing import List, Optional, Set
from datetime import datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from pynput import mouse, keyboard as kb
import keyboard
import pyautogui

pyautogui.FAILSAFE = False


# ============================ Model ============================

@dataclass
class ScheduleConfig:
    enabled: bool = False
    days: Set[str] = field(default_factory=set)
    time_interval_enabled: bool = False
    from_time: str = "09:00"
    to_time: str = "17:00"


@dataclass
class Step:
    kind: str
    args: dict
    timestamp: float = field(default_factory=time.time)

    def get_relative_time(self, first_time: float) -> float:
        return max(0, self.timestamp - first_time)

    def describe(self) -> str:
        if self.kind == "Wait":
            return f"Wait {self.args.get('seconds', 0)} s"
        if self.kind == "LaunchPath":
            return f"Launch '{self.args.get('path', '')}' {self.args.get('args','')}"
        if self.kind == "ClickAt":
            return f"Click at ({self.args.get('x')}, {self.args.get('y')}) btn={self.args.get('button','left')}"
        if self.kind == "MoveMouse":
            return f"Move to ({self.args.get('x')}, {self.args.get('y')}) dur={self.args.get('duration',0)}"
        if self.kind == "SendKeys":
            txt = self.args.get('text','')
            return f"Type: '{txt[:40]}{'...' if len(txt) > 40 else ''}'"
        if self.kind == "Hotkey":
            return f"Hotkey: {' + '.join(self.args.get('combo', []))}"
        return f"{self.kind} {self.args}"


# ============================ Scheduler ============================

class Scheduler:
    def __init__(self, controller):
        self.ctrl = controller
        self.running = False
        self._thread = None
        self._last_run_minute = None

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self._thread.start()
        print("[SCHEDULER] Started")

    def stop(self):
        self.running = False
        print("[SCHEDULER] Stopped")

    def _scheduler_loop(self):
        while self.running:
            try:
                if self.ctrl.schedule_config.enabled and not self.ctrl.playing:
                    if self._should_run_now():
                        print("[SCHEDULER] ⏰ Schedule matched! Starting playback...")
                        self.ctrl.log("⏰ Scheduled playback starting...")
                        self.ctrl.play()
                        self.ctrl.ui_queue.put(("state", None))
            except Exception as e:
                print(f"[SCHEDULER] Error: {e}")

            time.sleep(30)

    def _should_run_now(self) -> bool:
        now = datetime.now()
        current_day = now.strftime("%A")
        current_time = now.strftime("%H:%M")
        current_minute = current_time

        config = self.ctrl.schedule_config
        if current_minute == self._last_run_minute:
            return False

        if config.days and current_day not in config.days:
            print(f"[SCHEDULER] Day check failed: {current_day} not in {config.days}")
            return False

        if config.time_interval_enabled:
            def t2m(s: str) -> int:
                h, m = map(int, s.split(":"))
                return h * 60 + m

            cur = t2m(current_time)
            a = t2m(config.from_time)
            b = t2m(config.to_time)

            if b < a:
                in_range = cur >= a or cur <= b
            else:
                in_range = a <= cur <= b

            if not in_range:
                print(f"[SCHEDULER] Time check failed: {current_time} not in {config.from_time}-{config.to_time}")
                return False

        print(f"[SCHEDULER] ✓ Schedule match: {current_day} at {current_time}")
        self._last_run_minute = current_minute
        return True


# ============================ Controller ============================

class TaskController:
    def __init__(self, log_fn):
        self.steps: List[Step] = []
        self.log = log_fn
        self.schedule_config = ScheduleConfig()
        self.scheduler = Scheduler(self)

        # Recorder
        self.recording = False
        self._mouse_listener = None
        self._kb_listener = None

        # Playback
        self.playing = False
        self.paused = False
        self._play_thread: Optional[threading.Thread] = None
        self.playback_speed = 1.0
        self.loop_enabled = False
        self.loop_count = 1
        self.run_continuously = False

        # UI queue
        self.ui_queue = queue.Queue()

        print("[CTRL] TaskController initialized")
        self.scheduler.start()

    # ----- JSON (save/load)

    def to_json(self) -> str:
        print(f"[CTRL] Saving to JSON: {len(self.steps)} steps")
        data = {
            'steps': [asdict(s) for s in self.steps],
            'schedule': {
                'enabled': self.schedule_config.enabled,
                'days': list(self.schedule_config.days),
                'time_interval_enabled': self.schedule_config.time_interval_enabled,
                'from_time': self.schedule_config.from_time,
                'to_time': self.schedule_config.to_time
            }
        }
        return json.dumps(data, indent=2, ensure_ascii=False)

    def load_json(self, data: str):
        print("[CTRL] Loading from JSON...")
        obj = json.loads(data)
        self.steps = []
        for o in obj.get('steps', []):
            step = Step(kind=o['kind'], args=o['args'])
            if 'timestamp' in o:
                step.timestamp = o['timestamp']
            self.steps.append(step)
        print(f"[CTRL] Loaded {len(self.steps)} steps")

        if 'schedule' in obj:
            sch = obj['schedule']
            self.schedule_config = ScheduleConfig(
                enabled=sch.get('enabled', False),
                days=set(sch.get('days', [])),
                time_interval_enabled=sch.get('time_interval_enabled', False),
                from_time=sch.get('from_time', '09:00'),
                to_time=sch.get('to_time', '17:00')
            )
            print(f"[CTRL] Schedule loaded: enabled={self.schedule_config.enabled}, days={self.schedule_config.days}")

    # ----- Steps ops

    def add_step(self, step: Step):
        self.steps.append(step)
        print(f"[CTRL] Added step: {step.describe()}")
        self.log(f"+ {step.describe()}")

    def delete_indices(self, idxs: List[int]):
        if not idxs:
            return
        print(f"[CTRL] Deleting indices: {idxs}")
        for i in sorted(set(idxs), reverse=True):
            if 0 <= i < len(self.steps):
                self.log(f"- Delete: {self.steps[i].describe()}")
                del self.steps[i]
        print(f"[CTRL] After delete: {len(self.steps)} steps remain")

    # ----- Recording

    def start_recording(self):
        if self.recording:
            return
        self.recording = True
        self.log("🔴 Recording started (Press ESC or F1 to stop)")
        print("[CTRL] Recording STARTED")

        def on_click(x, y, button, pressed):
            if not self.recording:
                return
            if pressed:
                self.add_step(Step("ClickAt", {"x": x, "y": y, "button": str(button).split(".")[-1]}))
                self.ui_queue.put(("refresh", None))

        def on_press(key):
            if not self.recording:
                return
            try:
                if hasattr(key, 'char') and key.char:
                    self.add_step(Step("SendKeys", {"text": key.char}))
                else:
                    name = str(key).replace('Key.', '')
                    self.add_step(Step("Hotkey", {"combo": [name]}))
                self.ui_queue.put(("refresh", None))
            except Exception as e:
                print(f"[CTRL] Error recording key: {e}")

        self._mouse_listener = mouse.Listener(on_click=on_click)
        self._kb_listener = kb.Listener(on_press=on_press)
        self._mouse_listener.start()
        self._kb_listener.start()
        print("[CTRL] Mouse and keyboard listeners started")

    def stop_recording(self):
        if not self.recording:
            return
        self.recording = False
        self.log("⏹ Recording stopped")
        print("[CTRL] Recording STOPPED")
        try:
            if self._mouse_listener:
                self._mouse_listener.stop()
        except Exception:
            pass
        try:
            if self._kb_listener:
                self._kb_listener.stop()
        except Exception:
            pass
        self._mouse_listener = None
        self._kb_listener = None

    # ----- Playback

    def play(self, indices: Optional[List[int]] = None):
        if self.playing:
            return
        if not self.steps:
            self.log("ℹ️ No steps to play.")
            return

        self.playing = True
        self.paused = False

        steps = self.steps if not indices else [self.steps[i] for i in sorted(indices) if 0 <= i < len(self.steps)]
        mode = "continuously" if self.run_continuously else (f"{self.loop_count} times" if self.loop_enabled else "once")
        self.log(f"▶️ Playing task {mode} (Speed: {self.playback_speed}x)")
        print(f"[CTRL] Will play {len(steps)} steps")

        def runner():
            try:
                def do_pass():
                    first_ts = steps[0].timestamp
                    last_rel = 0.0
                    for st in steps:
                        while self.paused and self.playing:
                            time.sleep(0.05)
                        if not self.playing:
                            return
                        rel = st.get_relative_time(first_ts)
                        delay = max(0.0, (rel - last_rel)) / max(0.01, self.playback_speed)
                        time.sleep(delay)
                        last_rel = rel
                        self.execute_step(st)

                if self.run_continuously:
                    it = 0
                    while self.playing:
                        it += 1
                        self.log(f"🔄 Continuous run iteration #{it}")
                        do_pass()
                        if not self.playing:
                            break
                else:
                    loops = self.loop_count if self.loop_enabled else 1
                    for i in range(loops):
                        if not self.playing:
                            break
                        if loops > 1:
                            self.log(f"🔄 Loop {i+1}/{loops}")
                        do_pass()

                self.log("✅ Playback completed")
            except Exception as e:
                self.log(f"❌ Playback error: {e}")
            finally:
                self.playing = False
                self.paused = False
                self.ui_queue.put(("state", None))

        self._play_thread = threading.Thread(target=runner, daemon=True)
        self._play_thread.start()

    def toggle_pause(self):
        if self.playing:
            self.paused = not self.paused
            self.log("⏸ Paused" if self.paused else "▶️ Resumed")
            self.ui_queue.put(("state", None))

    def stop(self):
        if self.recording:
            self.stop_recording()
        if self.playing:
            self.playing = False
            self.paused = False
            self.log("⏹ Playback stopped")

    # ----- Execute a step

    def execute_step(self, st: Step):
        k = st.kind
        a = st.args

        def adjusted_sleep(seconds):
            time.sleep(seconds / max(0.01, self.playback_speed))

        if k == "Wait":
            adjusted_sleep(float(a.get("seconds", 0)))
        elif k == "LaunchPath":
            path = a.get("path", "").strip()
            args = a.get("args", "").strip()
            if not path:
                return
            if os.path.isfile(path) and not path.lower().endswith(".exe"):
                os.startfile(path)
            else:
                if args:
                    subprocess.Popen([path] + args.split())
                else:
                    subprocess.Popen([path])
            adjusted_sleep(float(a.get("post_wait", 0)))
        elif k == "MoveMouse":
            duration = float(a.get("duration", 0)) / max(0.01, self.playback_speed)
            pyautogui.moveTo(a.get("x", 0), a.get("y", 0), duration=duration)
        elif k == "ClickAt":
            pyautogui.click(a.get("x", 0), a.get("y", 0), button=a.get("button", "left"))
        elif k == "SendKeys":
            text = a.get("text", "")
            interval = float(a.get("interval", 0)) / max(0.01, self.playback_speed)
            if interval == 0 and len(text) > 1:
                interval = 0.01 / max(0.01, self.playback_speed)
            pyautogui.typewrite(text, interval=interval)
        elif k == "Hotkey":
            combo = a.get("combo", [])
            if combo:
                pyautogui.hotkey(*combo)


# ============================ Schedule Dialog ============================

class ScheduleDialog(tk.Toplevel):
    def __init__(self, parent, schedule_config: ScheduleConfig):
        super().__init__(parent)
        self.title("Schedule Settings")
        self.geometry("650x640")
        self.resizable(True, True)

        self.config_obj = schedule_config
        self.result = None

        self.transient(parent)
        self.grab_set()

        self._build_ui()

    def _build_ui(self):
        main = ttk.Frame(self, padding=20)
        main.pack(fill=tk.BOTH, expand=True)

        self.enable_var = tk.BooleanVar(value=self.config_obj.enabled)
        ttk.Checkbutton(main, text="Enable Schedule", variable=self.enable_var,
                        command=self.on_enable_change).pack(anchor='w', pady=(0, 15))

        ttk.Label(main, text="Days:").pack(anchor='w', pady=(0, 5))
        days_frame = ttk.LabelFrame(main, padding=10)
        days_frame.pack(fill=tk.X, pady=(0, 15))

        self.day_vars = {}
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        for i, day in enumerate(days):
            var = tk.BooleanVar(value=day in self.config_obj.days)
            self.day_vars[day] = var
            row = i // 2
            col = i % 2
            ttk.Checkbutton(days_frame, text=day, variable=var).grid(row=row, column=col, sticky='w', padx=10, pady=3)

        ttk.Button(days_frame, text="📅 Select Today", command=self.select_today)\
            .grid(row=4, column=0, columnspan=2, pady=(10, 0))

        ttk.Label(main, text="Time Interval (Optional)").pack(anchor='w', pady=(10, 5))
        time_frame = ttk.LabelFrame(main, padding=10)
        time_frame.pack(fill=tk.X, pady=(0, 15))

        self.time_enable_var = tk.BooleanVar(value=self.config_obj.time_interval_enabled)
        ttk.Checkbutton(time_frame, text="Enable time interval",
                        variable=self.time_enable_var,
                        command=self.on_time_enable_change).pack(anchor='w', pady=(0, 10))

        from_frame = ttk.Frame(time_frame); from_frame.pack(fill=tk.X, pady=5)
        ttk.Label(from_frame, text="From time:", width=12).pack(side=tk.LEFT)
        self.from_entry = ttk.Entry(from_frame, width=10); self.from_entry.pack(side=tk.LEFT, padx=5)
        self.from_entry.insert(0, self.config_obj.from_time)
        ttk.Label(from_frame, text="(ex: 21:00 for 9 PM)", foreground="gray").pack(side=tk.LEFT, padx=5)

        to_frame = ttk.Frame(time_frame); to_frame.pack(fill=tk.X, pady=5)
        ttk.Label(to_frame, text="To time:", width=12).pack(side=tk.LEFT)
        self.to_entry = ttk.Entry(to_frame, width=10); self.to_entry.pack(side=tk.LEFT, padx=5)
        self.to_entry.insert(0, self.config_obj.to_time)
        ttk.Label(to_frame, text="(ex: 08:00 for 8 AM)", foreground="gray").pack(side=tk.LEFT, padx=5)

        ttk.Label(time_frame, text="⏰ Overnight interval: Ex: 21:00 - 03:00",
                  foreground="blue", font=("Arial", 9)).pack(anchor='w', pady=(10, 0))

        self.on_time_enable_change()

        btn_frame = ttk.Frame(main); btn_frame.pack(pady=(20, 0))
        ttk.Button(btn_frame, text="Save", width=12, command=self.on_save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", width=12, command=self.destroy).pack(side=tk.LEFT, padx=5)

        self.bind('<Return>', lambda e: self.on_save())
        self.bind('<Escape>', lambda e: self.destroy())

    def select_today(self):
        today = datetime.now().strftime("%A")
        for day, var in self.day_vars.items():
            var.set(day == today)

    def on_enable_change(self):
        pass

    def on_time_enable_change(self):
        enabled = self.time_enable_var.get()
        state = 'normal' if enabled else 'disabled'
        self.from_entry.config(state=state)
        self.to_entry.config(state=state)

    def on_save(self):
        selected_days = {day for day, var in self.day_vars.items() if var.get()}
        self.config_obj.enabled = self.enable_var.get()
        self.config_obj.days = selected_days
        self.config_obj.time_interval_enabled = self.time_enable_var.get()
        self.config_obj.from_time = self.from_entry.get()
        self.config_obj.to_time = self.to_entry.get()
        self.result = self.config_obj
        self.destroy()


# ============================ Tooltip ============================

class ToolTip:
    def __init__(self, widget, text, delay_ms=400, padx=12, pady=8):
        self.widget = widget
        self.text = text
        self.delay_ms = delay_ms
        self.padx = padx
        self.pady = pady
        self._id_after = None
        self._tip = None
        widget.bind("<Enter>", self._on_enter, add="+")
        widget.bind("<Leave>", self._on_leave, add="+")
        widget.bind("<Motion>", self._on_motion, add="+")

    def _on_enter(self, _):
        self._schedule()

    def _on_leave(self, _):
        self._cancel()
        self._hide()

    def _on_motion(self, event):
        if self._tip is not None:
            x = event.x_root + self.padx
            y = event.y_root + self.pady
            self._tip.geometry(f"+{x}+{y}")

    def _schedule(self):
        self._cancel()
        self._id_after = self.widget.after(self.delay_ms, self._show)

    def _cancel(self):
        if self._id_after is not None:
            self.widget.after_cancel(self._id_after)
            self._id_after = None

    def _show(self):
        if self._tip or not self.text:
            return
        self._tip = tk.Toplevel(self.widget)
        self._tip.wm_overrideredirect(True)
        self._tip.attributes("-topmost", True)
        label = tk.Label(self._tip, text=self.text, justify="left", relief="solid",
                         borderwidth=1, padx=8, pady=4, bg="#ffffe0")
        label.pack()
        try:
            x, y = self.widget.winfo_pointerxy()
        except tk.TclError:
            x = self.widget.winfo_rootx()
            y = self.widget.winfo_rooty() + self.widget.winfo_height()
        self._tip.geometry(f"+{x + self.padx}+{y + self.pady}")

    def _hide(self):
        if self._tip is not None:
            self._tip.destroy()
            self._tip = None


# ============================ Mini Mode ============================

class MiniModeWindow(tk.Toplevel):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.title("BEBE")
        self.resizable(False, False)

        self.ctrl = controller
        self.parent_app = parent

        self.withdraw()
        self.update_idletasks()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        window_width = 280
        window_height = 80
        x = screen_width - window_width - 10
        y = screen_height - window_height - 70
        self.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.deiconify()

        self.attributes('-topmost', True)
        self._build_ui()
        self._start_update_loop()

        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        btn_frame = ttk.Frame(self, padding=5)
        btn_frame.pack(fill=tk.BOTH, expand=True)

        self.btn_record = ttk.Button(btn_frame, text="●", width=3, command=self.toggle_record)
        self.btn_record.grid(row=0, column=0, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Record", font=('Arial', 7)).grid(row=1, column=0)

        self.btn_play = ttk.Button(btn_frame, text="▶", width=3, command=self.play_task)
        self.btn_play.grid(row=0, column=1, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Play", font=('Arial', 7)).grid(row=1, column=1)

        self.btn_pause = ttk.Button(btn_frame, text="⏸", width=3, command=self.pause_task)
        self.btn_pause.grid(row=0, column=2, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Pause", font=('Arial', 7)).grid(row=1, column=2)

        self.btn_stop = ttk.Button(btn_frame, text="⏹", width=3, command=self.stop_task)
        self.btn_stop.grid(row=0, column=3, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Stop", font=('Arial', 7)).grid(row=1, column=3)

        for i in range(4):
            btn_frame.grid_columnconfigure(i, weight=1)
        btn_frame.grid_rowconfigure(0, weight=1)

        ToolTip(self.btn_record, "Înregistrează/Opresc înregistrarea (F1)", delay_ms=300)
        ToolTip(self.btn_play, "Rulează taskul (F9)", delay_ms=300)
        ToolTip(self.btn_pause, "Pauză redare (F10)", delay_ms=300)
        ToolTip(self.btn_stop, "Oprește redare/înregistrare (ESC)", delay_ms=300)

    def toggle_record(self):
        if self.ctrl.recording:
            self.ctrl.stop_recording()
        else:
            self.ctrl.start_recording()
        self.parent_app._update_ui_state()

    def play_task(self):
        self.ctrl.play()
        self.parent_app._update_ui_state()

    def pause_task(self):
        self.ctrl.toggle_pause()
        self.parent_app._update_ui_state()

    def stop_task(self):
        self.ctrl.stop()
        self.parent_app._update_ui_state()

    def _start_update_loop(self):
        self._update_buttons()
        self.after(100, self._start_update_loop)

    def _update_buttons(self):
        rec = self.ctrl.recording
        play = self.ctrl.playing
        self.btn_record.config(text="⏺" if rec else "●")
        self.btn_play.config(state='disabled' if (rec or play) else 'normal')
        self.btn_pause.config(state='normal' if play else 'disabled')
        self.btn_stop.config(state='normal' if (rec or play) else 'disabled')

    def on_close(self):
        self.parent_app.mini_mode_var.set(False)
        self.parent_app.mini_window = None
        self.parent_app.deiconify()
        self.parent_app.lift()
        self.parent_app.focus_force()
        self.parent_app.log("🔼 Mini Mode deactivated")
        self.destroy()


# ============================ Logs Window ============================

class LogsWindow(tk.Toplevel):
    def __init__(self, parent, log_text_widget):
        super().__init__(parent)
        self.title("BEBE - Logs")
        self.geometry("800x500")
        self.log_source = log_text_widget
        self._build_ui()
        self._refresh_logs()
        self.after(1000, self._auto_refresh)

    def _build_ui(self):
        toolbar = ttk.Frame(self); toolbar.pack(fill=tk.X, padx=5, pady=5)
        ttk.Button(toolbar, text="📋 Copy All", command=self.copy_all).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="💾 Save to File", command=self.save_to_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑 Clear Logs", command=self.clear_logs).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="📝 Open in Notepad", command=self.open_notepad).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔄 Refresh", command=self._refresh_logs).pack(side=tk.LEFT, padx=2)

        text_frame = ttk.Frame(self); text_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.text = tk.Text(text_frame, wrap='word')
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scrollbar.set)
        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def _refresh_logs(self):
        content = self.log_source.get('1.0', 'end')
        self.text.delete('1.0', 'end')
        self.text.insert('1.0', content)
        self.text.see('end')

    def _auto_refresh(self):
        if self.winfo_exists():
            self._refresh_logs()
            self.after(1000, self._auto_refresh)

    def copy_all(self):
        content = self.text.get('1.0', 'end-1c')
        self.clipboard_clear()
        self.clipboard_append(content)

    def save_to_file(self):
        fp = filedialog.asksaveasfilename(defaultextension=".txt",
                                          filetypes=[["Text Files","*.txt"], ["All Files","*.*"]])
        if fp:
            with open(fp, 'w', encoding='utf-8') as f:
                f.write(self.text.get('1.0', 'end-1c'))

    def clear_logs(self):
        if messagebox.askyesno("Clear Logs", "Clear all logs?"):
            self.log_source.delete('1.0', 'end')
            self._refresh_logs()

    def open_notepad(self):
        temp_file = os.path.join(os.environ.get('TEMP', '.'), 'bebe_logs.txt')
        with open(temp_file, 'w', encoding='utf-8') as f:
            f.write(self.text.get('1.0', 'end-1c'))
        subprocess.Popen(['notepad.exe', temp_file])


# ============================ Main App ============================

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BEBE - Task Recorder - Version 5.4")
        self.geometry("1400x700")

        # Tema & culori (mov foarte deschis)
        self.configure(bg="#F5E9FF")
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except Exception:
            pass
        palette_bg = "#F5E9FF"
        for name in ("TFrame", "TLabelframe", "TLabel", "TLabelframe.Label"):
            style.configure(name, background=palette_bg)

        # Hidden log buffer
        self.log_text = tk.Text(self)

        self.ctrl = TaskController(self.log)
        self.mini_window = None

        self._build_menu()
        self._build_ui()
        self._wire_hotkeys()
        self.after(100, self._poll_ui_queue)

    # ----- Menu

    def _build_menu(self):
        menubar = tk.Menu(self); self.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Task", command=self.new_task, accelerator="Ctrl+N")
        file_menu.add_command(label="Open Task...", command=self.load_json, accelerator="Ctrl+O")
        file_menu.add_command(label="Save Task", command=self.save_json, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)

        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)

        self.bind_all("<Control-n>", lambda e: self.new_task())
        self.bind_all("<Control-o>", lambda e: self.load_json())
        self.bind_all("<Control-s>", lambda e: self.save_json())

    # ----- Hotkeys

    def _wire_hotkeys(self):
        keyboard.add_hotkey('esc', lambda: self.safe_stop())
        keyboard.add_hotkey('f1', lambda: self.toggle_record())
        keyboard.add_hotkey('f9', lambda: self._toggle_play_hotkey())
        keyboard.add_hotkey('f10', lambda: self.ctrl.toggle_pause())

    def safe_stop(self):
        self.ctrl.stop()
        self._update_ui_state()
        self._refresh_events_list()

    def _toggle_play_hotkey(self):
        if self.ctrl.playing:
            self.ctrl.stop()
        else:
            sel = list(self.tree.selection())
            indices = [int(item.split('_')[1]) for item in sel] if sel else None
            self.ctrl.play(indices)
        self._update_ui_state()

    # ----- UI

    def _build_ui(self):
        main = ttk.Frame(self); main.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Record
        rec_frame = ttk.LabelFrame(main, text="Record Task", padding=10)
        rec_frame.pack(fill=tk.X, padx=4, pady=4)
        rec_top = ttk.Frame(rec_frame); rec_top.pack(fill=tk.X)

        self.btn_start_rec = ttk.Button(rec_top, text="Start Recording", command=self.toggle_record, width=20)
        self.btn_start_rec.pack(side=tk.LEFT, padx=5)

        self.btn_stop_rec = ttk.Button(rec_top, text="Stop Recording", command=self.toggle_record,
                                       width=20, state='disabled')
        self.btn_stop_rec.pack(side=tk.LEFT, padx=5)

        self.rec_status_label = ttk.Label(rec_top, text="Ready for Recording",
                                          foreground="blue", font=("Arial", 10, "bold"))
        self.rec_status_label.pack(side=tk.LEFT, padx=20)

        ttk.Label(rec_frame, text="Hotkeys: F1 = Record On/Off, F9 = Play/Stop, F10 = Pause, ESC = STOP",
                  foreground="gray").pack(pady=(5, 0))

        # Play
        play_frame = ttk.LabelFrame(main, text="Play Task", padding=10)
        play_frame.pack(fill=tk.X, padx=4, pady=4)
        play_top = ttk.Frame(play_frame); play_top.pack(fill=tk.X)

        self.btn_play = ttk.Button(play_top, text="Play", command=self.play_task, width=15)
        self.btn_play.pack(side=tk.LEFT, padx=5)

        self.btn_pause = ttk.Button(play_top, text="Pause (F10)", command=self.pause_task,
                                    width=15, state='disabled')
        self.btn_pause.pack(side=tk.LEFT, padx=5)

        self.btn_stop = ttk.Button(play_top, text="Stop Playback (Esc)", command=self.safe_stop,
                                   width=20, state='disabled')
        self.btn_stop.pack(side=tk.LEFT, padx=5)

        self.play_status_label = ttk.Label(play_top, text="Nothing is Playing",
                                           foreground="green", font=("Arial", 10, "bold"))
        self.play_status_label.pack(side=tk.LEFT, padx=20)

        controls = ttk.Frame(play_frame); controls.pack(fill=tk.X, pady=(10, 0))
        ttk.Label(controls, text="Playback Speed:").pack(side=tk.LEFT, padx=5)
        self.speed_var = tk.DoubleVar(value=2.0)
        self.speed_slider = ttk.Scale(controls, from_=0.1, to=5.0, variable=self.speed_var,
                                      orient=tk.HORIZONTAL, length=200, command=self.on_speed_change)
        self.speed_slider.pack(side=tk.LEFT, padx=5)
        self.speed_label = ttk.Label(controls, text="2.0x", width=6); self.speed_label.pack(side=tk.LEFT, padx=5)

        self.loop_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Loop", variable=self.loop_var,
                        command=self.on_loop_change).pack(side=tk.LEFT, padx=15)

        ttk.Label(controls, text="×").pack(side=tk.LEFT)
        self.loop_count_var = tk.IntVar(value=1)
        loop_spin = ttk.Spinbox(controls, from_=1, to=999, width=5, textvariable=self.loop_count_var,
                                command=self.on_loop_count_change)
        loop_spin.pack(side=tk.LEFT, padx=5)

        self.continuous_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Run continuously until ESC/F9",
                        variable=self.continuous_var, command=self.on_continuous_change)\
            .pack(side=tk.LEFT, padx=15)

        ttk.Button(controls, text="Schedule Settings (Shift+C)",
                   command=self.show_schedule_settings).pack(side=tk.LEFT, padx=15)

        self.mini_mode_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Mini Mode", variable=self.mini_mode_var,
                        command=self.toggle_mini_mode).pack(side=tk.RIGHT, padx=5)

        # Tabs
        tab_control = ttk.Notebook(main); tab_control.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        events_tab = ttk.Frame(tab_control); tab_control.add(events_tab, text="Events")
        self._build_events_tab(events_tab)

        files_tab = ttk.Frame(tab_control); tab_control.add(files_tab, text="Task Files")
        self._build_files_tab(files_tab)

        self._update_ui_state()

    def _build_events_tab(self, parent):
        top_bar = ttk.Frame(parent); top_bar.pack(fill=tk.X, padx=5, pady=5)
        ttk.Label(top_bar, text="Events (Optimized with Context)", font=("Arial", 10, "bold"))\
            .pack(side=tk.LEFT)

        tree_frame = ttk.Frame(parent); tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.tree = ttk.Treeview(tree_frame, columns=("#", "Time", "Type", "Details"),
                                 show='headings', selectmode='extended')
        self.tree.heading("#", text="#")
        self.tree.heading("Time", text="Time (s)")
        self.tree.heading("Type", text="Type")
        self.tree.heading("Details", text="Details")
        self.tree.column("#", width=50, anchor='center')
        self.tree.column("Time", width=100, anchor='center')
        self.tree.column("Type", width=150, anchor='w')
        self.tree.column("Details", width=800, anchor='w')
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # Bindings
        self.tree.bind('<Delete>', lambda e: self.delete_selected())
        self.tree.bind('<Double-Button-1>', lambda e: self.edit_selected())
        self.tree.bind('<Control-a>', lambda e: self.select_all())
        self.tree.bind('<Control-A>', lambda e: self.select_all())
        self.tree.bind('<Control-Delete>', lambda e: self.delete_selected())
        self.tree.bind('<Button-3>', self.show_context_menu)
        self._create_context_menu()

        # Toolbar
        sidebar = ttk.Frame(parent); sidebar.pack(fill=tk.X, padx=5, pady=5)
        ttk.Button(sidebar, text="▲ Move Up", command=self.move_up, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="▼ Move Down", command=self.move_down, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Separator(sidebar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        ttk.Button(sidebar, text="✓ Select All", command=self.select_all, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="Clear Selection", command=self.clear_selection, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Separator(sidebar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        ttk.Button(sidebar, text="🗑 Delete Selected", command=self.delete_selected, width=17).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="✏️ Edit Step", command=self.edit_selected, width=14).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="➕ Add Step", command=self.add_step_dialog, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Separator(sidebar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        ttk.Button(sidebar, text="📋 Logs", command=self.show_logs, width=10).pack(side=tk.LEFT, padx=2)

    def _create_context_menu(self):
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Delete Event (Del)", command=self.delete_selected)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Scale Timestamps (Speed Adjust)...", command=self.scale_timestamps)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Delete All Events", command=self.delete_all_events)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Edit Step...", command=self.edit_selected)
        self.context_menu.add_command(label="Duplicate Step", command=self.duplicate_selected)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Select All (Ctrl+A)", command=self.select_all)

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item and item not in self.tree.selection():
            self.tree.selection_set(item)
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def _build_files_tab(self, parent):
        info = ttk.Label(parent, text="Task Files Manager - Save and load multiple task configurations", padding=20)
        info.pack()
        files_frame = ttk.Frame(parent); files_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        self.files_list = tk.Listbox(files_frame, height=15)
        self.files_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        btn_frame = ttk.Frame(files_frame); btn_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=10)
        ttk.Button(btn_frame, text="Browse & Load...", command=self.load_json, width=15).pack(pady=5)
        ttk.Button(btn_frame, text="Save As...", command=self.save_json, width=15).pack(pady=5)
        ttk.Button(btn_frame, text="Refresh List", command=self.refresh_files_list, width=15).pack(pady=5)
        ttk.Button(btn_frame, text="Delete File", command=self.delete_task_file, width=15).pack(pady=5)
        self.refresh_files_list()

    # ----- UI helpers

    def _update_ui_state(self):
        rec = self.ctrl.recording
        play = self.ctrl.playing
        paused = self.ctrl.paused
        self.btn_start_rec.config(state='disabled' if rec else 'normal')
        self.btn_stop_rec.config(state='normal' if rec else 'disabled')
        self.rec_status_label.config(text="● Recording..." if rec else "Ready for Recording",
                                     foreground="red" if rec else "blue")
        self.btn_play.config(state='disabled' if (rec or play) else 'normal')
        self.btn_pause.config(state='normal' if play else 'disabled')
        self.btn_stop.config(state='normal' if play else 'disabled')
        self.play_status_label.config(
            text="⏸ Paused" if paused else ("● Playing..." if play else "Nothing is Playing"),
            foreground="orange" if paused else ("red" if play else "green")
        )

    def _refresh_events_list(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        if not self.ctrl.steps:
            return
        first_time = self.ctrl.steps[0].timestamp
        for i, step in enumerate(self.ctrl.steps):
            rel_time = f"{step.get_relative_time(first_time):.3f}"
            self.tree.insert('', 'end', iid=f'step_{i}',
                             values=(i + 1, rel_time, step.kind, step.describe()))

    def _poll_ui_queue(self):
        try:
            while True:
                kind, payload = self.ctrl.ui_queue.get_nowait()
                if kind == "refresh":
                    self._refresh_events_list()
                elif kind == "state":
                    self._update_ui_state()
        except queue.Empty:
            pass
        self.after(100, self._poll_ui_queue)

    # ----- Control callbacks

    def on_speed_change(self, val):
        speed = float(val)
        self.ctrl.playback_speed = speed
        self.speed_label.config(text=f"{speed:.1f}x")

    def on_loop_change(self):
        enabled = self.loop_var.get()
        self.ctrl.loop_enabled = enabled
        if enabled and self.continuous_var.get():
            messagebox.showwarning("Configuration Conflict",
                                   "You cannot enable both 'Loop' and 'Run continuously' at the same time.\n\n"
                                   "'Run continuously' will be disabled.")
            self.continuous_var.set(False)
            self.ctrl.run_continuously = False

    def on_loop_count_change(self):
        self.ctrl.loop_count = self.loop_count_var.get()

    def on_continuous_change(self):
        enabled = self.continuous_var.get()
        self.ctrl.run_continuously = enabled
        if enabled and self.loop_var.get():
            messagebox.showwarning("Configuration Conflict",
                                   "You cannot enable both 'Run continuously' and 'Loop' at the same time.\n\n"
                                   "'Loop' will be disabled.")
            self.loop_var.set(False)
            self.ctrl.loop_enabled = False

    def toggle_record(self):
        if self.ctrl.recording:
            self.ctrl.stop_recording()
        else:
            self.ctrl.start_recording()
        self._update_ui_state()

    def play_task(self):
        sel = list(self.tree.selection())
        indices = [int(item.split('_')[1]) for item in sel] if sel else None
        self.ctrl.play(indices)
        self._update_ui_state()

    def pause_task(self):
        self.ctrl.toggle_pause()
        self._update_ui_state()

    def select_all(self):
        for item in self.tree.get_children():
            self.tree.selection_add(item)

    def clear_selection(self):
        self.tree.selection_remove(*self.tree.selection())

    def delete_selected(self):
        sel = list(self.tree.selection())
        if not sel:
            return
        indices = [int(item.split('_')[1]) for item in sel]
        self.ctrl.delete_indices(indices)
        self._refresh_events_list()

    def move_up(self):
        sel = list(self.tree.selection())
        if not sel: return
        indices = sorted([int(item.split('_')[1]) for item in sel])
        for i in indices:
            if i > 0:
                self.ctrl.steps[i-1], self.ctrl.steps[i] = self.ctrl.steps[i], self.ctrl.steps[i-1]
        self._refresh_events_list()
        for i in [max(0, idx-1) for idx in indices]:
            self.tree.selection_add(f'step_{i}')

    def move_down(self):
        sel = list(self.tree.selection())
        if not sel: return
        indices = sorted([int(item.split('_')[1]) for item in sel], reverse=True)
        for i in indices:
            if i < len(self.ctrl.steps) - 1:
                self.ctrl.steps[i+1], self.ctrl.steps[i] = self.ctrl.steps[i], self.ctrl.steps[i+1]
        self._refresh_events_list()
        for i in [min(len(self.ctrl.steps)-1, idx+1) for idx in indices]:
            self.tree.selection_add(f'step_{i}')

    def edit_selected(self):
        sel = self.tree.selection()
        if not sel or len(sel) != 1:
            messagebox.showinfo("Edit", "Please select exactly one step to edit")
            return
        idx = int(sel[0].split('_')[1])
        step = self.ctrl.steps[idx]

        dialog = tk.Toplevel(self); dialog.title(f"Edit Step #{idx+1}")
        dialog.geometry("600x300"); dialog.transient(self)

        ttk.Label(dialog, text=f"Type: {step.kind}", font=("Arial", 10, "bold")).pack(pady=10)
        ttk.Label(dialog, text="Arguments (JSON):").pack()
        text = tk.Text(dialog, height=10, width=70); text.pack(padx=10, pady=5)
        text.insert('1.0', json.dumps(step.args, indent=2))

        def save():
            try:
                step.args = json.loads(text.get('1.0', 'end'))
                self._refresh_events_list()
                dialog.destroy()
                self.log(f"✏️ Edited step #{idx+1}")
            except json.JSONDecodeError as e:
                messagebox.showerror("Error", f"Invalid JSON: {e}")

        ttk.Button(dialog, text="Save", command=save).pack(pady=10)

    def add_step_dialog(self):
        dialog = tk.Toplevel(self); dialog.title("Add New Step")
        dialog.geometry("600x400"); dialog.transient(self)

        ttk.Label(dialog, text="Step Type:", font=("Arial", 10, "bold")).pack(pady=10)
        step_type = tk.StringVar(value="Wait")
        types = ["Wait", "LaunchPath", "ClickAt", "MoveMouse", "SendKeys", "Hotkey"]
        ttk.Combobox(dialog, textvariable=step_type, values=types, state='readonly', width=30).pack()

        ttk.Label(dialog, text="Arguments (JSON):").pack(pady=10)
        text = tk.Text(dialog, height=12, width=70); text.pack(padx=10, pady=5)
        text.insert('1.0', '{\n  "": ""\n}')

        def add():
            try:
                args = json.loads(text.get('1.0', 'end'))
                step = Step(step_type.get(), args)
                self.ctrl.add_step(step)
                self._refresh_events_list()
                dialog.destroy()
            except json.JSONDecodeError as e:
                messagebox.showerror("Error", f"Invalid JSON: {e}")

        ttk.Button(dialog, text="Add Step", command=add).pack(pady=10)

    def scale_timestamps(self):
        sel = list(self.tree.selection())
        if not sel:
            messagebox.showinfo("Scale Timestamps", "Please select events to scale")
            return

        dialog = tk.Toplevel(self); dialog.title("Scale Timestamps")
        dialog.geometry("400x200"); dialog.transient(self); dialog.resizable(False, False)

        ttk.Label(dialog, text="Adjust playback speed for selected events:",
                  font=("Arial", 10, "bold")).pack(pady=15)
        frame = ttk.Frame(dialog); frame.pack(pady=10)

        ttk.Label(frame, text="Speed multiplier:").pack(side=tk.LEFT, padx=5)
        speed_var = tk.DoubleVar(value=1.0)
        speed_entry = ttk.Entry(frame, textvariable=speed_var, width=10); speed_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(frame, text="(0.5 = half speed, 2.0 = double speed)").pack(side=tk.LEFT, padx=5)

        def apply_scale():
            try:
                multiplier = speed_var.get()
                if multiplier <= 0:
                    messagebox.showerror("Error", "Speed must be greater than 0")
                    return
                indices = [int(item.split('_')[1]) for item in sel]
                for idx in indices:
                    step = self.ctrl.steps[idx]
                    if step.kind == "Wait":
                        cur = step.args.get("seconds", 0)
                        step.args["seconds"] = cur / multiplier
                    elif step.kind == "MoveMouse":
                        cur = step.args.get("duration", 0)
                        step.args["duration"] = cur / multiplier
                self._refresh_events_list()
                self.log(f"⏱️ Scaled {len(indices)} events by {multiplier}x")
                dialog.destroy()
            except ValueError:
                messagebox.showerror("Error", "Invalid speed value")

        btn_frame = ttk.Frame(dialog); btn_frame.pack(pady=20)
        ttk.Button(btn_frame, text="Apply", command=apply_scale, width=12).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy, width=12).pack(side=tk.LEFT, padx=5)

    def delete_all_events(self):
        if not self.ctrl.steps:
            messagebox.showinfo("Delete All", "No events to delete")
            return
        count = len(self.ctrl.steps)
        if messagebox.askyesno("Delete All Events",
                               f"Are you sure you want to delete all {count} events?\n\nThis cannot be undone!"):
            self.ctrl.steps.clear()
            self._refresh_events_list()
            self.log(f"🗑️ Deleted all {count} events")

    def duplicate_selected(self):
        sel = list(self.tree.selection())
        if not sel:
            messagebox.showinfo("Duplicate", "Please select events to duplicate")
            return
        indices = sorted([int(item.split('_')[1]) for item in sel])
        insert_pos = indices[-1] + 1
        duplicated = []
        for idx in indices:
            original = self.ctrl.steps[idx]
            dup = Step(kind=original.kind, args=original.args.copy(), timestamp=time.time())
            duplicated.append(dup)
        for i, dup in enumerate(duplicated):
            self.ctrl.steps.insert(insert_pos + i, dup)
        self._refresh_events_list()
        self.log(f"📋 Duplicated {len(duplicated)} events")
        for i in range(len(duplicated)):
            self.tree.selection_add(f'step_{insert_pos + i}')

    # ----- Files & schedule

    def show_logs(self):
        LogsWindow(self, self.log_text)

    def new_task(self):
        if messagebox.askyesno("New Task", "Clear all steps and start new task?"):
            self.ctrl.steps.clear()
            self._refresh_events_list()
            self.log("📄 New task created")

    def save_json(self):
        fp = filedialog.asksaveasfilename(defaultextension=".json",
                                          filetypes=[["JSON Task Files","*.json"], ["All Files","*.*"]],
                                          initialdir=os.getcwd())
        if not fp:
            return
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(self.ctrl.to_json())
        self.log(f"💾 Saved: {fp}")
        self.refresh_files_list()

    def load_json(self):
        fp = filedialog.askopenfilename(filetypes=[["JSON Task Files","*.json"], ["All Files","*.*"]],
                                        initialdir=os.getcwd())
        if not fp:
            return
        with open(fp, 'r', encoding='utf-8') as f:
            self.ctrl.load_json(f.read())
        self._refresh_events_list()
        self.log(f"📂 Loaded: {fp}")
        if self.ctrl.schedule_config.enabled:
            sch = self.ctrl.schedule_config
            info = []
            if sch.days:
                info.append(f"Days: {', '.join(sorted(sch.days))}")
            if sch.time_interval_enabled:
                info.append(f"Time: {sch.from_time}-{sch.to_time}")
            self.log(f"📅 Schedule: {' | '.join(info)}")

    def refresh_files_list(self):
        if not hasattr(self, 'files_list'):
            return
        self.files_list.delete(0, 'end')
        for f in os.listdir('.'):
            if f.endswith('.json'):
                self.files_list.insert('end', f)

    def load_from_list(self):
        sel = self.files_list.curselection()
        if not sel:
            return
        filename = self.files_list.get(sel[0])
        with open(filename, 'r', encoding='utf-8') as f:
            self.ctrl.load_json(f.read())
        self._refresh_events_list()
        self.log(f"📂 Loaded: {filename}")

    def delete_task_file(self):
        sel = self.files_list.curselection()
        if not sel:
            return
        filename = self.files_list.get(sel[0])
        if messagebox.askyesno("Delete", f"Delete {filename}?"):
            os.remove(filename)
            self.refresh_files_list()
            self.log(f"🗑 Deleted: {filename}")

    def show_schedule_settings(self):
        dialog = ScheduleDialog(self, self.ctrl.schedule_config)
        self.wait_window(dialog)
        if dialog.result:
            self.ctrl.schedule_config = dialog.result
            if self.ctrl.schedule_config.enabled:
                info = []
                if self.ctrl.schedule_config.days:
                    info.append(f"Days: {', '.join(sorted(self.ctrl.schedule_config.days))}")
                if self.ctrl.schedule_config.time_interval_enabled:
                    info.append(f"{self.ctrl.schedule_config.from_time}-{self.ctrl.schedule_config.to_time}")
                self.log(f"📅 Schedule updated: {' | '.join(info)}")

    def toggle_mini_mode(self):
        enabled = self.mini_mode_var.get()
        if enabled:
            if not self.mini_window or not self.mini_window.winfo_exists():
                self.iconify()
                self.after(200, lambda: self._create_mini_window())
        else:
            if self.mini_window and self.mini_window.winfo_exists():
                self.mini_window.destroy()
                self.mini_window = None
            self.deiconify()
            self.lift()
            self.focus_force()
            self.log("🔼 Mini Mode deactivated")

    def _create_mini_window(self):
        self.mini_window = MiniModeWindow(self, self.ctrl)
        self.log("🔽 Mini Mode activated")

    def show_about(self):
        messagebox.showinfo(
            "About BEBE Task Recorder",
            "BEBE Task Recorder v5.4\n\n"
            "Advanced task automation and recording tool\n"
            "with hotkeys, scheduling, and playback control.\n\n"
            "© 2025 - Created for workflow automation"
        )

    def log(self, msg: str):
        ts = time.strftime('%H:%M:%S')
        self.log_text.insert('end', f"[{ts}] {msg}\n")
        self.log_text.see('end')


# ============================ Main ============================

if __name__ == '__main__':
    try:
        print("\n" + "="*60)
        print("BEBE Task Recorder v5.4 Starting...")
        print("="*60 + "\n")
        app = App()
        app.mainloop()
    except Exception as e:
        print(f"\n[ERROR] Application crashed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n[APP] Cleaning up...")
        try:
            keyboard.unhook_all()
        except Exception:
            pass
        print("[APP] Shutdown complete")
