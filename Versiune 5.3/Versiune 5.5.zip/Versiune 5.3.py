# -*- coding: utf-8 -*-
"""
BEBE Task Builder — Version 5.4 (Functional Scheduler)

Adăugat:
  • Scheduler funcțional care verifică ora și ziua
  • Pornește automat playback când se potrivește schedule-ul
"""

import json
import os
import queue
import threading
import time
import subprocess
from dataclasses import dataclass, asdict, field
from typing import List, Optional, Set
from datetime import datetime, timedelta

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from pynput import mouse, keyboard as kb
import keyboard
import pyautogui

pyautogui.FAILSAFE = False

# ---------------------------- Model ----------------------------

@dataclass
class ScheduleConfig:
    enabled: bool = False
    days: Set[str] = field(default_factory=set)
    time_interval_enabled: bool = False
    from_time: str = "09:00"
    to_time: str = "17:00"

@dataclass
class Step:
    kind: str
    args: dict
    timestamp: float = field(default_factory=time.time)

    def get_relative_time(self, first_time: float) -> float:
        return max(0, self.timestamp - first_time)

    def describe(self) -> str:
        if self.kind == "Wait":
            return f"Wait {self.args.get('seconds', 0)} s"
        if self.kind == "LaunchPath":
            return f"Launch '{self.args.get('path', '')}' {self.args.get('args','')}"
        if self.kind == "ClickAt":
            return f"Click at ({self.args.get('x')}, {self.args.get('y')}) btn={self.args.get('button','left')}"
        if self.kind == "MoveMouse":
            return f"Move to ({self.args.get('x')}, {self.args.get('y')}) dur={self.args.get('duration',0)}"
        if self.kind == "SendKeys":
            txt = self.args.get('text','')
            return f"Type: '{txt[:40]}{'...' if len(txt) > 40 else ''}'"
        if self.kind == "Hotkey":
            return f"Hotkey: {' + '.join(self.args.get('combo', []))}"
        return f"{self.kind} {self.args}"

# ---------------------------- Scheduler Thread ----------------------------

class Scheduler:
    def __init__(self, controller):
        self.ctrl = controller
        self.running = False
        self._thread = None
        self._last_run_minute = None  # Previne rulări multiple în același minut

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self._thread.start()
        print("[SCHEDULER] Started")

    def stop(self):
        self.running = False
        print("[SCHEDULER] Stopped")

    def _scheduler_loop(self):
        """Background thread care verifică continuu dacă trebuie să ruleze taskul"""
        while self.running:
            try:
                if self.ctrl.schedule_config.enabled and not self.ctrl.playing:
                    if self._should_run_now():
                        print("[SCHEDULER] ⏰ Schedule matched! Starting playback...")
                        self.ctrl.log("⏰ Scheduled playback starting...")
                        self.ctrl.play()
                        self.ctrl.ui_queue.put(("state", None))
            except Exception as e:
                print(f"[SCHEDULER] Error: {e}")

            time.sleep(30)  # Verifică la fiecare 30 secunde

    def _should_run_now(self) -> bool:
        """Verifică dacă trebuie să ruleze acum bazat pe schedule config"""
        now = datetime.now()
        current_day = now.strftime("%A")
        current_time = now.strftime("%H:%M")
        current_minute = now.strftime("%H:%M")

        config = self.ctrl.schedule_config

        # Previne rulări multiple în același minut
        if current_minute == self._last_run_minute:
            return False

        # Verifică ziua
        if config.days and current_day not in config.days:
            print(f"[SCHEDULER] Day check failed: {current_day} not in {config.days}")
            return False

        # Verifică intervalul de timp (dacă e activat)
        if config.time_interval_enabled:
            from_time = config.from_time
            to_time = config.to_time

            # Convertire la minute pentru comparație
            def time_to_minutes(time_str):
                h, m = map(int, time_str.split(':'))
                return h * 60 + m

            current_minutes = time_to_minutes(current_time)
            from_minutes = time_to_minutes(from_time)
            to_minutes = time_to_minutes(to_time)

            # Handle overnight intervals (ex: 21:00 - 03:00)
            if to_minutes < from_minutes:
                # Overnight: trebuie să fie după from SAU înainte de to
                in_range = current_minutes >= from_minutes or current_minutes <= to_minutes
            else:
                # Normal: trebuie să fie între from și to
                in_range = from_minutes <= current_minutes <= to_minutes

            if not in_range:
                print(f"[SCHEDULER] Time check failed: {current_time} not in {from_time}-{to_time}")
                return False

        # Toate condițiile sunt îndeplinite
        print(f"[SCHEDULER] ✓ Schedule match: {current_day} at {current_time}")
        self._last_run_minute = current_minute
        return True

# ---------------------------- Controller ----------------------------

class TaskController:
    def __init__(self, log_fn):
        self.steps: List[Step] = []
        self.log = log_fn
        self.schedule_config = ScheduleConfig()
        self.scheduler = Scheduler(self)

        # Recorder
        self.recording = False
        self._mouse_listener = None
        self._kb_listener = None
        self._record_start_time = None

        # Playback
        self.playing = False
        self.paused = False
        self._play_thread: Optional[threading.Thread] = None
        self.playback_speed = 1.0
        self.loop_enabled = False
        self.loop_count = 1
        self.run_continuously = False

        # Event queue (UI-safe)
        self.ui_queue = queue.Queue()

        print("[CTRL] TaskController initialized")

        # Start scheduler
        self.scheduler.start()

    def to_json(self) -> str:
        print(f"[CTRL] Saving to JSON: {len(self.steps)} steps")
        data = {
            'steps': [asdict(s) for s in self.steps],
            'schedule': {
                'enabled': self.schedule_config.enabled,
                'days': list(self.schedule_config.days),
                'time_interval_enabled': self.schedule_config.time_interval_enabled,
                'from_time': self.schedule_config.from_time,
                'to_time': self.schedule_config.to_time
            }
        }
        return json.dumps(data, indent=2, ensure_ascii=False)

    def load_json(self, data: str):
        print("[CTRL] Loading from JSON...")
        obj = json.loads(data)
        self.steps = []
        for o in obj.get('steps', []):
            step = Step(kind=o['kind'], args=o['args'])
            if 'timestamp' in o:
                step.timestamp = o['timestamp']
            self.steps.append(step)
        print(f"[CTRL] Loaded {len(self.steps)} steps")

        if 'schedule' in obj:
            sch = obj['schedule']
            self.schedule_config = ScheduleConfig(
                enabled=sch.get('enabled', False),
                days=set(sch.get('days', [])),
                time_interval_enabled=sch.get('time_interval_enabled', False),
                from_time=sch.get('from_time', '09:00'),
                to_time=sch.get('to_time', '17:00')
            )
            print(f"[CTRL] Schedule loaded: enabled={self.schedule_config.enabled}, days={self.schedule_config.days}")

    def add_step(self, step: Step):
        self.steps.append(step)
        print(f"[CTRL] Added step: {step.describe()}")
        self.log(f"+ {step.describe()}")

    def delete_indices(self, idxs: List[int]):
        if not idxs:
            print("[CTRL] Delete called with empty indices")
            return
        print(f"[CTRL] Deleting indices: {idxs}")
        idxs = sorted(set(idxs), reverse=True)
        for i in idxs:
            if 0 <= i < len(self.steps):
                self.log(f"- Delete: {self.steps[i].describe()}")
                del self.steps[i]
        print(f"[CTRL] After delete: {len(self.steps)} steps remain")

    def start_recording(self):
        if self.recording:
            print("[CTRL] Already recording, ignoring start request")
            return
        self.recording = True
        self._record_start_time = time.time()
        print(f"[CTRL] Recording STARTED at {self._record_start_time}")
        self.log("🔴 Recording started (Press ESC or F9 to stop)")

        def on_click(x, y, button, pressed):
            if not self.recording:
                return
            if pressed:
                print(f"[CTRL] Mouse click recorded: ({x}, {y}) {button}")
                self.add_step(Step("ClickAt", {"x": x, "y": y, "button": str(button).split(".")[-1]}))
                self.ui_queue.put(("refresh", None))

        def on_press(key):
            if not self.recording:
                return
            try:
                if hasattr(key, 'char') and key.char:
                    print(f"[CTRL] Key recorded: {key.char}")
                    self.add_step(Step("SendKeys", {"text": key.char}))
                else:
                    name = str(key).replace('Key.', '')
                    print(f"[CTRL] Special key recorded: {name}")
                    self.add_step(Step("Hotkey", {"combo": [name]}))
                self.ui_queue.put(("refresh", None))
            except Exception as e:
                print(f"[CTRL] Error recording key: {e}")

        self._mouse_listener = mouse.Listener(on_click=on_click)
        self._kb_listener = kb.Listener(on_press=on_press)
        self._mouse_listener.start()
        self._kb_listener.start()
        print("[CTRL] Mouse and keyboard listeners started")

    def stop_recording(self):
        if not self.recording:
            print("[CTRL] Not recording, ignoring stop request")
            return
        self.recording = False
        print("[CTRL] Recording STOPPED")
        self.log("⏹ Recording stopped")
        try:
            if self._mouse_listener:
                self._mouse_listener.stop()
                print("[CTRL] Mouse listener stopped")
        except Exception as e:
            print(f"[CTRL] Error stopping mouse listener: {e}")
        try:
            if self._kb_listener:
                self._kb_listener.stop()
                print("[CTRL] Keyboard listener stopped")
        except Exception as e:
            print(f"[CTRL] Error stopping keyboard listener: {e}")
        self._mouse_listener = None
        self._kb_listener = None

    def play(self, indices: Optional[List[int]] = None):
        if self.playing:
            print("[CTRL] Already playing, ignoring play request")
            return
        if not self.steps:
            print("[CTRL] No steps to play")
            self.log("ℹ️ No steps to play.")
            return

        print(f"[CTRL] Play called: speed={self.playback_speed}x, loop={self.loop_enabled}, continuous={self.run_continuously}")

        self.playing = True
        self.paused = False

        steps = self.steps if not indices else [self.steps[i] for i in sorted(indices) if 0 <= i < len(self.steps)]
        mode = "continuously" if self.run_continuously else (f"{self.loop_count} times" if self.loop_enabled else "once")
        self.log(f"▶️ Playing task {mode} (Speed: {self.playback_speed}x)")
        print(f"[CTRL] Will play {len(steps)} steps")

        def run():
            try:
                def do_pass():
                    """Execută un pas complet prin toți steps, cu timing corect"""
                    first_ts = steps[0].timestamp
                    last_rel = 0.0

                    for st in steps:
                        # Verifică pause
                        while self.paused and self.playing:
                            time.sleep(0.05)
                        if not self.playing:
                            print("[CTRL] Playback stopped by user")
                            return

                        # Calculează timpul relativ al acestui step față de primul
                        rel = st.get_relative_time(first_ts)

                        # Calculează delay-ul dintre ultimul step și acesta
                        # Apoi aplică playback_speed
                        delay = max(0.0, (rel - last_rel)) / max(0.01, self.playback_speed)
                        time.sleep(delay)

                        last_rel = rel

                        # Execută step-ul
                        self.execute_step(st)

                # Rulează conform setărilor (continuous/loop/once)
                if self.run_continuously:
                    print("[CTRL] Running continuously until stopped...")
                    iteration = 0
                    while self.playing:
                        iteration += 1
                        print(f"[CTRL] Continuous iteration #{iteration}")
                        self.log(f"🔄 Continuous run iteration #{iteration}")
                        do_pass()
                        if not self.playing:
                            break
                else:
                    loops = self.loop_count if self.loop_enabled else 1
                    print(f"[CTRL] Running {loops} loops")
                    for loop_num in range(loops):
                        if not self.playing:
                            break
                        if loops > 1:
                            print(f"[CTRL] Loop {loop_num + 1}/{loops}")
                            self.log(f"🔄 Loop {loop_num + 1}/{loops}")
                        do_pass()
                        if not self.playing:
                            break

                print("[CTRL] Playback COMPLETED")
                self.log("✅ Playback completed")
            except Exception as e:
                print(f"[CTRL] Playback ERROR: {e}")
                self.log(f"❌ Playback error: {e}")
            finally:
                self.playing = False
                self.paused = False
                self.ui_queue.put(("state", None))
                print("[CTRL] Playback thread finished")

        self._play_thread = threading.Thread(target=run, daemon=True)
        self._play_thread.start()
        print("[CTRL] Playback thread started")

    def toggle_pause(self):
        if self.playing:
            self.paused = not self.paused
            print(f"[CTRL] Playback {'PAUSED' if self.paused else 'RESUMED'}")
            self.log("⏸ Paused" if self.paused else "▶️ Resumed")
            self.ui_queue.put(("state", None))

    def stop(self):
        print("[CTRL] Stop called")
        if self.recording:
            self.stop_recording()
        if self.playing:
            self.playing = False
            self.paused = False
            print("[CTRL] Playback STOPPED")
            self.log("⏹ Playback stopped")

    def execute_step(self, st: Step):
        print(f"[CTRL] Executing: {st.describe()}")
        k = st.kind
        a = st.args

        def adjusted_sleep(seconds):
            actual_sleep = seconds / self.playback_speed
            print(f"[CTRL] Sleeping {actual_sleep:.3f}s (original: {seconds}s, speed: {self.playback_speed}x)")
            time.sleep(actual_sleep)

        if k == "Wait":
            adjusted_sleep(float(a.get("seconds", 0)))
        elif k == "LaunchPath":
            path = a.get("path", "").strip()
            args = a.get("args", "").strip()
            if not path:
                return
            print(f"[CTRL] Launching: {path} {args}")
            if os.path.isfile(path) and not path.lower().endswith(".exe"):
                os.startfile(path)
            else:
                if args:
                    subprocess.Popen([path] + args.split())
                else:
                    subprocess.Popen([path])
            adjusted_sleep(float(a.get("post_wait", 0)))
        elif k == "MoveMouse":
            duration = float(a.get("duration", 0)) / self.playback_speed
            print(f"[CTRL] Moving mouse to ({a.get('x')}, {a.get('y')}) in {duration}s")
            pyautogui.moveTo(a.get("x", 0), a.get("y", 0), duration=duration)
        elif k == "ClickAt":
            print(f"[CTRL] Clicking at ({a.get('x')}, {a.get('y')})")
            pyautogui.click(a.get("x", 0), a.get("y", 0), button=a.get("button", "left"))
        elif k == "SendKeys":
            interval = float(a.get("interval", 0)) / self.playback_speed
            text = a.get("text", "")
            print(f"[CTRL] Typing: {text[:20]}...")
            pyautogui.typewrite(text, interval=interval)
        elif k == "Hotkey":
            combo = a.get("combo", [])
            print(f"[CTRL] Hotkey: {combo}")
            if combo:
                pyautogui.hotkey(*combo)

# ---------------------------- Schedule Dialog ----------------------------

class ScheduleDialog(tk.Toplevel):
    def __init__(self, parent, schedule_config: ScheduleConfig):
        super().__init__(parent)
        self.title("Schedule Settings")
        self.geometry("650x640")
        self.resizable(True, True)

        print("[SCHEDULE] Dialog opened")

        self.config_obj = schedule_config
        self.result = None

        self.transient(parent)
        self.grab_set()

        self._build_ui()

    def _build_ui(self):
        main = ttk.Frame(self, padding=20)
        main.pack(fill=tk.BOTH, expand=True)

        # Enable Schedule
        self.enable_var = tk.BooleanVar(value=self.config_obj.enabled)
        ttk.Checkbutton(main, text="Enable Schedule", variable=self.enable_var,
                       command=self.on_enable_change).pack(anchor='w', pady=(0, 15))

        # Days section
        days_label = ttk.Label(main, text="Days:")
        days_label.pack(anchor='w', pady=(0, 5))

        days_frame = ttk.LabelFrame(main, padding=10)
        days_frame.pack(fill=tk.X, pady=(0, 15))

        self.day_vars = {}
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

        for i, day in enumerate(days):
            var = tk.BooleanVar(value=day in self.config_obj.days)
            self.day_vars[day] = var

            row = i // 2
            col = i % 2
            ttk.Checkbutton(days_frame, text=day, variable=var).grid(
                row=row, column=col, sticky='w', padx=10, pady=3
            )

        # Select Today button
        ttk.Button(days_frame, text="📅 Select Today", command=self.select_today).grid(
            row=4, column=0, columnspan=2, pady=(10, 0)
        )

        # Time Interval section
        time_label = ttk.Label(main, text="Time Interval (Optional)")
        time_label.pack(anchor='w', pady=(10, 5))

        time_frame = ttk.LabelFrame(main, padding=10)
        time_frame.pack(fill=tk.X, pady=(0, 15))

        self.time_enable_var = tk.BooleanVar(value=self.config_obj.time_interval_enabled)
        ttk.Checkbutton(time_frame, text="Enable time interval",
                       variable=self.time_enable_var,
                       command=self.on_time_enable_change).pack(anchor='w', pady=(0, 10))

        # From time
        from_frame = ttk.Frame(time_frame)
        from_frame.pack(fill=tk.X, pady=5)
        ttk.Label(from_frame, text="From time:", width=12).pack(side=tk.LEFT)
        self.from_entry = ttk.Entry(from_frame, width=10)
        self.from_entry.pack(side=tk.LEFT, padx=5)
        self.from_entry.insert(0, self.config_obj.from_time)
        ttk.Label(from_frame, text="(ex: 21:00 for 9 PM)", foreground="gray").pack(side=tk.LEFT, padx=5)

        # To time
        to_frame = ttk.Frame(time_frame)
        to_frame.pack(fill=tk.X, pady=5)
        ttk.Label(to_frame, text="To time:", width=12).pack(side=tk.LEFT)
        self.to_entry = ttk.Entry(to_frame, width=10)
        self.to_entry.pack(side=tk.LEFT, padx=5)
        self.to_entry.insert(0, self.config_obj.to_time)
        ttk.Label(to_frame, text="(ex: 08:00 for 8 AM)", foreground="gray").pack(side=tk.LEFT, padx=5)

        # Overnight interval info
        overnight_label = ttk.Label(time_frame,
                                    text="⏰ Overnight interval: Ex: 21:00 - 03:00 (9 PM - 3 AM)",
                                    foreground="blue", font=("Arial", 9))
        overnight_label.pack(anchor='w', pady=(10, 0))

        self.on_time_enable_change()

        # Buttons
        btn_frame = ttk.Frame(main)
        btn_frame.pack(pady=(20, 0))

        ttk.Button(btn_frame, text="Save", width=12, command=self.on_save).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", width=12, command=self.destroy).pack(side=tk.LEFT, padx=5)

        self.bind('<Return>', lambda e: self.on_save())
        self.bind('<Escape>', lambda e: self.destroy())

    def select_today(self):
        today = datetime.now().strftime("%A")
        print(f"[SCHEDULE] Select today: {today}")
        for day, var in self.day_vars.items():
            var.set(day == today)

    def on_enable_change(self):
        print(f"[SCHEDULE] Enable changed: {self.enable_var.get()}")

    def on_time_enable_change(self):
        enabled = self.time_enable_var.get()
        print(f"[SCHEDULE] Time interval enabled: {enabled}")
        state = 'normal' if enabled else 'disabled'
        self.from_entry.config(state=state)
        self.to_entry.config(state=state)

    def on_save(self):
        print("[SCHEDULE] Saving configuration...")

        selected_days = {day for day, var in self.day_vars.items() if var.get()}
        print(f"[SCHEDULE] Selected days: {selected_days}")

        self.config_obj.enabled = self.enable_var.get()
        self.config_obj.days = selected_days
        self.config_obj.time_interval_enabled = self.time_enable_var.get()
        self.config_obj.from_time = self.from_entry.get()
        self.config_obj.to_time = self.to_entry.get()

        print(f"[SCHEDULE] Configuration saved: enabled={self.config_obj.enabled}")

        self.result = self.config_obj
        self.destroy()



# ---------------------------- Tooltip Class ----------------------------

# ---------------------------- Tooltip Class ----------------------------

class ToolTip:
    """Tooltip simplu pentru orice widget Tk/ttk."""
    def __init__(self, widget, text, delay_ms=400, padx=12, pady=8):
        self.widget = widget
        self.text = text
        self.delay_ms = delay_ms
        self.padx = padx
        self.pady = pady
        self._id_after = None
        self._tip = None

        widget.bind("<Enter>", self._on_enter, add="+")
        widget.bind("<Leave>", self._on_leave, add="+")
        widget.bind("<Motion>", self._on_motion, add="+")

    def _on_enter(self, _):
        self._schedule()

    def _on_leave(self, _):
        self._cancel()
        self._hide()

    def _on_motion(self, event):
        # dacă tooltipul e deja vizibil, îl mutăm
        if self._tip is not None:
            x = event.x_root + self.padx
            y = event.y_root + self.pady
            self._tip.geometry(f"+{x}+{y}")

    def _schedule(self):
        self._cancel()
        self._id_after = self.widget.after(self.delay_ms, self._show)

    def _cancel(self):
        if self._id_after is not None:
            self.widget.after_cancel(self._id_after)
            self._id_after = None

    def _show(self):
        if self._tip or not self.text:
            return
        # fereastră „plutitoare" fără border
        self._tip = tk.Toplevel(self.widget)
        self._tip.wm_overrideredirect(True)  # fără decorații
        self._tip.attributes("-topmost", True)

        label = tk.Label(
            self._tip,
            text=self.text,
            justify="left",
            relief="solid",
            borderwidth=1,
            padx=8, pady=4,
            bg="#ffffe0"  # galben pal tipic pentru tooltip
        )
        label.pack()

        # poziționare inițială lângă cursor
        try:
            x, y = self.widget.winfo_pointerxy()
        except tk.TclError:
            x = self.widget.winfo_rootx()
            y = self.widget.winfo_rooty() + self.widget.winfo_height()
        self._tip.geometry(f"+{x + self.padx}+{y + self.pady}")

    def _hide(self):
        if self._tip is not None:
            self._tip.destroy()
            self._tip = None

# ---------------------------- Mini Mode Window ----------------------------

class MiniModeWindow(tk.Toplevel):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.title("BEBE")
        self.resizable(False, False)

        print("[MINI] Window created")

        self.ctrl = controller
        self.parent_app = parent

        # Ascunde fereastra temporar până calculăm poziția
        self.withdraw()

        # Calculare poziție pentru JOS-DREAPTA
        self.update_idletasks()
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        window_width = 280
        window_height = 80

        # JOS-DREAPTA: x mare (dreapta), y mare (jos)
        x = screen_width - window_width - 10
        y = screen_height - window_height - 70

        # Setează mărimea ȘI poziția o dată
        self.geometry(f"{window_width}x{window_height}+{x}+{y}")
        print(f"[MINI] Positioned at BOTTOM-RIGHT: x={x}, y={y} (screen: {screen_width}x{screen_height})")

        # Afișează fereastra la poziția corectă
        self.deiconify()

        self.attributes('-topmost', True)

        self._build_ui()
        self._start_update_loop()

        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        # Container pentru butoane
        btn_frame = ttk.Frame(self, padding=5)
        btn_frame.pack(fill=tk.BOTH, expand=True)

        # 4 butoane în grid 1x4
        self.btn_record = ttk.Button(btn_frame, text="●", width=3,
                                     command=self.toggle_record)
        self.btn_record.grid(row=0, column=0, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Record", font=('Arial', 7)).grid(row=1, column=0)

        self.btn_play = ttk.Button(btn_frame, text="▶", width=3,
                                   command=self.play_task)
        self.btn_play.grid(row=0, column=1, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Play", font=('Arial', 7)).grid(row=1, column=1)

        self.btn_pause = ttk.Button(btn_frame, text="⏸", width=3,
                                    command=self.pause_task)
        self.btn_pause.grid(row=0, column=2, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Pause", font=('Arial', 7)).grid(row=1, column=2)

        self.btn_stop = ttk.Button(btn_frame, text="⏹", width=3,
                                   command=self.stop_task)
        self.btn_stop.grid(row=0, column=3, padx=3, pady=3, sticky='nsew')
        ttk.Label(btn_frame, text="Stop", font=('Arial', 7)).grid(row=1, column=3)

        # Grid configuration
        for i in range(4):
            btn_frame.grid_columnconfigure(i, weight=1)
        btn_frame.grid_rowconfigure(0, weight=1)

        # Add tooltips to buttons cu delay de 300ms
        print("[MINI] Adding tooltips...")
        ToolTip(self.btn_record, "Înregistrează secvența (F1)", delay_ms=300)
        ToolTip(self.btn_play, "Rulează taskul (F9)", delay_ms=300)
        ToolTip(self.btn_pause, "Pauză redare (F10)", delay_ms=300)
        ToolTip(self.btn_stop, "Oprește redare/înregistrare (ESC)", delay_ms=300)
        print("[MINI] Tooltips added")

    def toggle_record(self):
        print("[MINI] Record button clicked")
        if self.ctrl.recording:
            self.ctrl.stop_recording()
        else:
            self.ctrl.start_recording()
        self.parent_app._update_ui_state()

    def play_task(self):
        print("[MINI] Play button clicked")
        self.ctrl.play()
        self.parent_app._update_ui_state()

    def pause_task(self):
        print("[MINI] Pause button clicked")
        self.ctrl.toggle_pause()
        self.parent_app._update_ui_state()

    def stop_task(self):
        print("[MINI] Stop button clicked")
        self.ctrl.stop()
        self.parent_app._update_ui_state()

    def _start_update_loop(self):
        self._update_buttons()
        self.after(100, self._start_update_loop)

    def _update_buttons(self):
        rec = self.ctrl.recording
        play = self.ctrl.playing

        self.btn_record.config(text="⏺" if rec else "●")
        self.btn_play.config(state='disabled' if (rec or play) else 'normal')
        self.btn_pause.config(state='normal' if play else 'disabled')
        self.btn_stop.config(state='normal' if (rec or play) else 'disabled')

    def on_close(self):
        print("[MINI] Window closing - restoring main window")

        # Dezactivează checkbox-ul Mini Mode
        self.parent_app.mini_mode_var.set(False)
        self.parent_app.mini_window = None

        # RESTAUREAZĂ fereastra principală
        self.parent_app.deiconify()
        self.parent_app.lift()
        self.parent_app.focus_force()

        print("[APP] Main window restored from Mini Mode close")
        self.parent_app.log("🔼 Mini Mode deactivated")

        # Distruge fereastra mică
        self.destroy()

# ---------------------------- Logs Window ----------------------------

class LogsWindow(tk.Toplevel):
    def __init__(self, parent, log_text_widget):
        super().__init__(parent)
        self.title("BEBE - Logs")
        self.geometry("800x500")

        print("[LOGS] Logs window opened")

        self.log_source = log_text_widget

        self._build_ui()
        self._refresh_logs()

        # Auto-refresh every second
        self.after(1000, self._auto_refresh)

    def _build_ui(self):
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(toolbar, text="📋 Copy All", command=self.copy_all).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="💾 Save to File", command=self.save_to_file).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑 Clear Logs", command=self.clear_logs).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="📝 Open in Notepad", command=self.open_notepad).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🔄 Refresh", command=self._refresh_logs).pack(side=tk.LEFT, padx=2)

        # Text widget
        text_frame = ttk.Frame(self)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.text = tk.Text(text_frame, wrap='word')
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scrollbar.set)

        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def _refresh_logs(self):
        # Get content from main app's log widget
        content = self.log_source.get('1.0', 'end')
        self.text.delete('1.0', 'end')
        self.text.insert('1.0', content)
        self.text.see('end')

    def _auto_refresh(self):
        if self.winfo_exists():
            self._refresh_logs()
            self.after(1000, self._auto_refresh)

    def copy_all(self):
        content = self.text.get('1.0', 'end-1c')
        self.clipboard_clear()
        self.clipboard_append(content)
        print("[LOGS] Copied to clipboard")

    def save_to_file(self):
        fp = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[["Text Files","*.txt"], ["All Files","*.*"]]
        )
        if fp:
            with open(fp, 'w', encoding='utf-8') as f:
                f.write(self.text.get('1.0', 'end-1c'))
            print(f"[LOGS] Saved to {fp}")

    def clear_logs(self):
        if messagebox.askyesno("Clear Logs", "Clear all logs?"):
            self.log_source.delete('1.0', 'end')
            self._refresh_logs()
            print("[LOGS] Logs cleared")

    def open_notepad(self):
        # Save to temp file and open in notepad
        temp_file = os.path.join(os.environ.get('TEMP', '.'), 'bebe_logs.txt')
        with open(temp_file, 'w', encoding='utf-8') as f:
            f.write(self.text.get('1.0', 'end-1c'))
        subprocess.Popen(['notepad.exe', temp_file])
        print(f"[LOGS] Opened in notepad: {temp_file}")

# ---------------------------- Main App ----------------------------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BEBE - Task Recorder - Version 5.3")
        self.geometry("1400x700")

        print("[APP] Application starting...")

        # Hidden log widget for logs window
        self.log_text = tk.Text(self)

        self.ctrl = TaskController(self.log)
        self.mini_window = None

        self._build_menu()
        self._build_ui()
        self._wire_hotkeys()
        self.after(100, self._poll_ui_queue)

        print("[APP] Application initialized")

    def _build_menu(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Task", command=self.new_task, accelerator="Ctrl+N")
        file_menu.add_command(label="Open Task...", command=self.load_json, accelerator="Ctrl+O")
        file_menu.add_command(label="Save Task", command=self.save_json, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)

        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)

        self.bind_all("<Control-n>", lambda e: self.new_task())
        self.bind_all("<Control-o>", lambda e: self.load_json())
        self.bind_all("<Control-s>", lambda e: self.save_json())

    def _wire_hotkeys(self):
        print("[APP] Wiring hotkeys...")
        keyboard.add_hotkey('esc', lambda: self.safe_stop())
        keyboard.add_hotkey('f9', lambda: self._toggle_play_hotkey())
        keyboard.add_hotkey('f10', lambda: self.ctrl.toggle_pause())
        print("[APP] Hotkeys registered: ESC, F9, F10")

    def safe_stop(self):
        print("[APP] Safe stop called")
        self.ctrl.stop()
        self._update_ui_state()

    def _toggle_play_hotkey(self):
        print("[APP] F9 hotkey pressed")
        if self.ctrl.playing:
            self.ctrl.stop()
        else:
            sel = list(self.tree.selection())
            indices = [int(item.split('_')[1]) for item in sel] if sel else None
            print(f"[APP] Playing with selection: {indices}")
            self.ctrl.play(indices)
        self._update_ui_state()

    def _build_ui(self):
        main = ttk.Frame(self)
        main.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # === RECORD TASK ===
        rec_frame = ttk.LabelFrame(main, text="Record Task", padding=10)
        rec_frame.pack(fill=tk.X, padx=4, pady=4)

        rec_top = ttk.Frame(rec_frame)
        rec_top.pack(fill=tk.X)

        self.btn_start_rec = ttk.Button(rec_top, text="Start Recording", command=self.toggle_record, width=20)
        self.btn_start_rec.pack(side=tk.LEFT, padx=5)

        self.btn_stop_rec = ttk.Button(rec_top, text="Stop Recording", command=self.toggle_record, width=20, state='disabled')
        self.btn_stop_rec.pack(side=tk.LEFT, padx=5)

        self.rec_status_label = ttk.Label(rec_top, text="Ready for Recording", foreground="blue", font=("Arial", 10, "bold"))
        self.rec_status_label.pack(side=tk.LEFT, padx=20)

        rec_info = ttk.Label(rec_frame, text="Press ESC or F9 from any application to stop recording", foreground="gray")
        rec_info.pack(pady=(5,0))

        # === PLAY TASK ===
        play_frame = ttk.LabelFrame(main, text="Play Task", padding=10)
        play_frame.pack(fill=tk.X, padx=4, pady=4)

        play_top = ttk.Frame(play_frame)
        play_top.pack(fill=tk.X)

        self.btn_play = ttk.Button(play_top, text="Play", command=self.play_task, width=15)
        self.btn_play.pack(side=tk.LEFT, padx=5)

        self.btn_pause = ttk.Button(play_top, text="Pause (F10)", command=self.pause_task, width=15, state='disabled')
        self.btn_pause.pack(side=tk.LEFT, padx=5)

        self.btn_stop = ttk.Button(play_top, text="Stop Playback (Esc)", command=self.safe_stop, width=20, state='disabled')
        self.btn_stop.pack(side=tk.LEFT, padx=5)

        self.play_status_label = ttk.Label(play_top, text="Nothing is Playing", foreground="green", font=("Arial", 10, "bold"))
        self.play_status_label.pack(side=tk.LEFT, padx=20)

        controls = ttk.Frame(play_frame)
        controls.pack(fill=tk.X, pady=(10,0))

        ttk.Label(controls, text="Playback Speed:").pack(side=tk.LEFT, padx=5)
        self.speed_var = tk.DoubleVar(value=2.0)
        self.speed_slider = ttk.Scale(controls, from_=0.1, to=5.0, variable=self.speed_var,
                                      orient=tk.HORIZONTAL, length=200, command=self.on_speed_change)
        self.speed_slider.pack(side=tk.LEFT, padx=5)
        self.speed_label = ttk.Label(controls, text="2.0x", width=6)
        self.speed_label.pack(side=tk.LEFT, padx=5)

        self.loop_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Loop", variable=self.loop_var, command=self.on_loop_change).pack(side=tk.LEFT, padx=15)

        ttk.Label(controls, text="×").pack(side=tk.LEFT)
        self.loop_count_var = tk.IntVar(value=1)
        loop_spin = ttk.Spinbox(controls, from_=1, to=999, width=5, textvariable=self.loop_count_var,
                               command=self.on_loop_count_change)
        loop_spin.pack(side=tk.LEFT, padx=5)

        self.continuous_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Run continuously until ESC/F9",
                       variable=self.continuous_var, command=self.on_continuous_change).pack(side=tk.LEFT, padx=15)

        ttk.Button(controls, text="Schedule Settings (Shift+C)",
                  command=self.show_schedule_settings).pack(side=tk.LEFT, padx=15)

        self.mini_mode_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(controls, text="Mini Mode", variable=self.mini_mode_var,
                       command=self.toggle_mini_mode).pack(side=tk.RIGHT, padx=5)

        # === TABS ===
        tab_control = ttk.Notebook(main)
        tab_control.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        events_tab = ttk.Frame(tab_control)
        tab_control.add(events_tab, text="Events")
        self._build_events_tab(events_tab)

        files_tab = ttk.Frame(tab_control)
        tab_control.add(files_tab, text="Task Files")
        self._build_files_tab(files_tab)

        self._update_ui_state()

    def _build_events_tab(self, parent):
        top_bar = ttk.Frame(parent)
        top_bar.pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(top_bar, text="Events (Optimized with Context)", font=("Arial", 10, "bold")).pack(side=tk.LEFT)

        tree_frame = ttk.Frame(parent)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.tree = ttk.Treeview(tree_frame, columns=("#", "Time", "Type", "Details"),
                                 show='headings', selectmode='extended')

        self.tree.heading("#", text="#")
        self.tree.heading("Time", text="Time (s)")
        self.tree.heading("Type", text="Type")
        self.tree.heading("Details", text="Details")

        self.tree.column("#", width=50, anchor='center')
        self.tree.column("Time", width=100, anchor='center')
        self.tree.column("Type", width=150, anchor='w')
        self.tree.column("Details", width=800, anchor='w')

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # Keyboard bindings
        print("[APP] Binding tree keyboard shortcuts...")
        self.tree.bind('<Delete>', lambda e: self.delete_selected())
        self.tree.bind('<Double-Button-1>', lambda e: self.edit_selected())
        self.tree.bind('<Control-a>', lambda e: self.select_all())
        self.tree.bind('<Control-A>', lambda e: self.select_all())

        # RIGHT CLICK CONTEXT MENU
        self.tree.bind('<Button-3>', self.show_context_menu)  # Right click
        print("[APP] Tree bindings: Delete, Double-click, Ctrl+A, Right-click menu")

        # Create context menu
        self._create_context_menu()

        # Sidebar cu butoane ORIZONTALE
        sidebar = ttk.Frame(parent)
        sidebar.pack(fill=tk.X, padx=5, pady=5)

        # Row 1: Move buttons
        ttk.Button(sidebar, text="▲ Move Up", command=self.move_up, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="▼ Move Down", command=self.move_down, width=12).pack(side=tk.LEFT, padx=2)

        ttk.Separator(sidebar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        # Row 2: Select buttons
        ttk.Button(sidebar, text="✓ Select All", command=self.select_all, width=12).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="Clear Selection", command=self.clear_selection, width=12).pack(side=tk.LEFT, padx=2)

        ttk.Separator(sidebar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        # Row 3: Action buttons
        ttk.Button(sidebar, text="🗑 Delete Selected", command=self.delete_selected, width=17).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="✏️Edit Step", command=self.edit_selected, width=14).pack(side=tk.LEFT, padx=2)
        ttk.Button(sidebar, text="➕ Add Step", command=self.add_step_dialog, width=12).pack(side=tk.LEFT, padx=2)

        ttk.Separator(sidebar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)

        # Logs button
        ttk.Button(sidebar, text="📋 Logs", command=self.show_logs, width=10).pack(side=tk.LEFT, padx=2)

    def _build_files_tab(self, parent):
        info = ttk.Label(parent, text="Task Files Manager - Save and load multiple task configurations",
                        padding=20)
        info.pack()

        files_frame = ttk.Frame(parent)
        files_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        self.files_list = tk.Listbox(files_frame, height=15)
        self.files_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        btn_frame = ttk.Frame(files_frame)
        btn_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=10)

        ttk.Button(btn_frame, text="Load Task", command=self.load_from_list, width=15).pack(pady=5)
        ttk.Button(btn_frame, text="Save As...", command=self.save_json, width=15).pack(pady=5)
        ttk.Button(btn_frame, text="Refresh List", command=self.refresh_files_list, width=15).pack(pady=5)
        ttk.Button(btn_frame, text="Delete File", command=self.delete_task_file, width=15).pack(pady=5)

        self.refresh_files_list()

    def _update_ui_state(self):
        rec = self.ctrl.recording
        play = self.ctrl.playing
        paused = self.ctrl.paused

        print(f"[APP] UI State: rec={rec}, play={play}, paused={paused}")

        self.btn_start_rec.config(state='disabled' if rec else 'normal')
        self.btn_stop_rec.config(state='normal' if rec else 'disabled')
        self.rec_status_label.config(
            text="● Recording..." if rec else "Ready for Recording",
            foreground="red" if rec else "blue"
        )

        self.btn_play.config(state='disabled' if (rec or play) else 'normal')
        self.btn_pause.config(state='normal' if play else 'disabled')
        self.btn_stop.config(state='normal' if play else 'disabled')
        self.play_status_label.config(
            text="⏸ Paused" if paused else ("● Playing..." if play else "Nothing is Playing"),
            foreground="orange" if paused else ("red" if play else "green")
        )

    def _refresh_events_list(self):
        print(f"[APP] Refreshing events list: {len(self.ctrl.steps)} steps")
        for item in self.tree.get_children():
            self.tree.delete(item)

        if not self.ctrl.steps:
            return

        first_time = self.ctrl.steps[0].timestamp
        for i, step in enumerate(self.ctrl.steps):
            rel_time = f"{step.get_relative_time(first_time):.3f}"
            self.tree.insert('', 'end', iid=f'step_{i}',
                           values=(i+1, rel_time, step.kind, step.describe()))
        print(f"[APP] Tree refreshed with {len(self.ctrl.steps)} items")

    def _poll_ui_queue(self):
        try:
            while True:
                kind, payload = self.ctrl.ui_queue.get_nowait()
                print(f"[APP] UI queue event: {kind}")
                if kind == "refresh":
                    self._refresh_events_list()
                elif kind == "state":
                    self._update_ui_state()
        except queue.Empty:
            pass
        self.after(100, self._poll_ui_queue)

    def on_speed_change(self, val):
        speed = float(val)
        self.ctrl.playback_speed = speed
        self.speed_label.config(text=f"{speed:.1f}x")
        print(f"[APP] Playback speed changed to {speed:.1f}x")

    def on_loop_change(self):
        enabled = self.loop_var.get()
        self.ctrl.loop_enabled = enabled
        print(f"[APP] Loop changed: {enabled}")

        if enabled and self.continuous_var.get():
            print("[APP] WARNING: Loop and Continuous both enabled!")
            messagebox.showwarning("Configuration Conflict",
                "You cannot enable both 'Loop' and 'Run continuously' at the same time.\n\n"
                "'Run continuously' will be disabled.")
            self.continuous_var.set(False)
            self.ctrl.run_continuously = False

    def on_loop_count_change(self):
        count = self.loop_count_var.get()
        self.ctrl.loop_count = count
        print(f"[APP] Loop count changed to {count}")

    def on_continuous_change(self):
        enabled = self.continuous_var.get()
        self.ctrl.run_continuously = enabled
        print(f"[APP] Run continuously changed: {enabled}")

        if enabled and self.loop_var.get():
            print("[APP] WARNING: Continuous and Loop both enabled!")
            messagebox.showwarning("Configuration Conflict",
                "You cannot enable both 'Run continuously' and 'Loop' at the same time.\n\n"
                "'Loop' will be disabled.")
            self.loop_var.set(False)
            self.ctrl.loop_enabled = False

    def toggle_record(self):
        print("[APP] Toggle record called")
        if self.ctrl.recording:
            self.ctrl.stop_recording()
        else:
            self.ctrl.start_recording()
        self._update_ui_state()

    def play_task(self):
        print("[APP] Play task button clicked")
        sel = list(self.tree.selection())
        indices = [int(item.split('_')[1]) for item in sel] if sel else None
        print(f"[APP] Selected indices: {indices}")
        self.ctrl.play(indices)
        self._update_ui_state()

    def pause_task(self):
        print("[APP] Pause task button clicked")
        self.ctrl.toggle_pause()
        self._update_ui_state()

    def select_all(self):
        print("[APP] Select all called")
        for item in self.tree.get_children():
            self.tree.selection_add(item)
        print(f"[APP] Selected {len(self.tree.get_children())} items")

    def clear_selection(self):
        print("[APP] Clear selection called")
        self.tree.selection_remove(*self.tree.selection())

    def delete_selected(self):
        sel = list(self.tree.selection())
        print(f"[APP] Delete selected: {len(sel)} items")
        if not sel:
            return
        indices = [int(item.split('_')[1]) for item in sel]
        self.ctrl.delete_indices(indices)
        self._refresh_events_list()

    def move_up(self):
        sel = list(self.tree.selection())
        print(f"[APP] Move up: {len(sel)} items")
        if not sel:
            return
        indices = sorted([int(item.split('_')[1]) for item in sel])
        for i in indices:
            if i > 0:
                self.ctrl.steps[i-1], self.ctrl.steps[i] = self.ctrl.steps[i], self.ctrl.steps[i-1]
        self._refresh_events_list()
        for i in [max(0, idx-1) for idx in indices]:
            self.tree.selection_add(f'step_{i}')

    def move_down(self):
        sel = list(self.tree.selection())
        print(f"[APP] Move down: {len(sel)} items")
        if not sel:
            return
        indices = sorted([int(item.split('_')[1]) for item in sel], reverse=True)
        for i in indices:
            if i < len(self.ctrl.steps)-1:
                self.ctrl.steps[i+1], self.ctrl.steps[i] = self.ctrl.steps[i], self.ctrl.steps[i+1]
        self._refresh_events_list()
        for i in [min(len(self.ctrl.steps)-1, idx+1) for idx in indices]:
            self.tree.selection_add(f'step_{i}')

    def edit_selected(self):
        sel = self.tree.selection()
        print(f"[APP] Edit selected: {len(sel)} items")
        if not sel or len(sel) != 1:
            messagebox.showinfo("Edit", "Please select exactly one step to edit")
            return

        idx = int(sel[0].split('_')[1])
        step = self.ctrl.steps[idx]

        dialog = tk.Toplevel(self)
        dialog.title(f"Edit Step #{idx+1}")
        dialog.geometry("600x300")
        dialog.transient(self)

        ttk.Label(dialog, text=f"Type: {step.kind}", font=("Arial", 10, "bold")).pack(pady=10)

        ttk.Label(dialog, text="Arguments (JSON):").pack()
        text = tk.Text(dialog, height=10, width=70)
        text.pack(padx=10, pady=5)
        text.insert('1.0', json.dumps(step.args, indent=2))

        def save():
            try:
                step.args = json.loads(text.get('1.0', 'end'))
                self._refresh_events_list()
                dialog.destroy()
                self.log(f"✏️ Edited step #{idx+1}")
                print(f"[APP] Step #{idx+1} edited successfully")
            except json.JSONDecodeError as e:
                print(f"[APP] JSON error in edit: {e}")
                messagebox.showerror("Error", f"Invalid JSON: {e}")

        ttk.Button(dialog, text="Save", command=save).pack(pady=10)

    def add_step_dialog(self):
        print("[APP] Add step dialog opened")
        dialog = tk.Toplevel(self)
        dialog.title("Add New Step")
        dialog.geometry("600x400")
        dialog.transient(self)

        ttk.Label(dialog, text="Step Type:", font=("Arial", 10, "bold")).pack(pady=10)

        step_type = tk.StringVar(value="Wait")
        types = ["Wait", "LaunchPath", "ClickAt", "MoveMouse", "SendKeys", "Hotkey"]
        ttk.Combobox(dialog, textvariable=step_type, values=types, state='readonly', width=30).pack()

        ttk.Label(dialog, text="Arguments (JSON):").pack(pady=10)
        text = tk.Text(dialog, height=12, width=70)
        text.pack(padx=10, pady=5)
        text.insert('1.0', '{\n  "": ""\n}')

        def add():
            try:
                args = json.loads(text.get('1.0', 'end'))
                step = Step(step_type.get(), args)
                self.ctrl.add_step(step)
                self._refresh_events_list()
                dialog.destroy()
                print(f"[APP] New step added: {step.describe()}")
            except json.JSONDecodeError as e:
                print(f"[APP] JSON error in add: {e}")
                messagebox.showerror("Error", f"Invalid JSON: {e}")

        ttk.Button(dialog, text="Add Step", command=add).pack(pady=10)

    def _create_context_menu(self):
        """Create right-click context menu for tree"""
        self.context_menu = tk.Menu(self, tearoff=0)

        self.context_menu.add_command(label="Delete Event (Del)", command=self.delete_selected)
        self.context_menu.add_command(label="Delete Selected Group (Ctrl+Del)", command=self.delete_selected)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Scale Timestamps (Speed Adjust)...", command=self.scale_timestamps)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Delete All Events", command=self.delete_all_events)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Edit Step...", command=self.edit_selected)
        self.context_menu.add_command(label="Duplicate Step", command=self.duplicate_selected)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Select All (Ctrl+A)", command=self.select_all)

        print("[APP] Context menu created")

    def show_context_menu(self, event):
        """Show context menu on right-click"""
        # Select item under cursor if not already selected
        item = self.tree.identify_row(event.y)
        if item and item not in self.tree.selection():
            self.tree.selection_set(item)

        # Show menu at cursor position
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

        print(f"[APP] Context menu shown at ({event.x_root}, {event.y_root})")

    def scale_timestamps(self):
        """Scale timestamps dialog"""
        sel = list(self.tree.selection())
        if not sel:
            messagebox.showinfo("Scale Timestamps", "Please select events to scale")
            return

        dialog = tk.Toplevel(self)
        dialog.title("Scale Timestamps")
        dialog.geometry("400x200")
        dialog.transient(self)
        dialog.resizable(False, False)

        ttk.Label(dialog, text="Adjust playback speed for selected events:",
                 font=("Arial", 10, "bold")).pack(pady=15)

        frame = ttk.Frame(dialog)
        frame.pack(pady=10)

        ttk.Label(frame, text="Speed multiplier:").pack(side=tk.LEFT, padx=5)

        speed_var = tk.DoubleVar(value=1.0)
        speed_entry = ttk.Entry(frame, textvariable=speed_var, width=10)
        speed_entry.pack(side=tk.LEFT, padx=5)

        ttk.Label(frame, text="(0.5 = half speed, 2.0 = double speed)").pack(side=tk.LEFT, padx=5)

        def apply_scale():
            try:
                multiplier = speed_var.get()
                if multiplier <= 0:
                    messagebox.showerror("Error", "Speed must be greater than 0")
                    return

                indices = [int(item.split('_')[1]) for item in sel]

                # Scale timestamps for Wait steps
                for idx in indices:
                    step = self.ctrl.steps[idx]
                    if step.kind == "Wait":
                        current = step.args.get("seconds", 0)
                        step.args["seconds"] = current / multiplier
                    elif step.kind == "MoveMouse":
                        current = step.args.get("duration", 0)
                        step.args["duration"] = current / multiplier

                self._refresh_events_list()
                self.log(f"⏱️ Scaled {len(indices)} events by {multiplier}x")
                dialog.destroy()
                print(f"[APP] Scaled {len(indices)} timestamps by {multiplier}x")

            except ValueError:
                messagebox.showerror("Error", "Invalid speed value")

        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=20)

        ttk.Button(btn_frame, text="Apply", command=apply_scale, width=12).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy, width=12).pack(side=tk.LEFT, padx=5)

    def delete_all_events(self):
        """Delete all events with confirmation"""
        if not self.ctrl.steps:
            messagebox.showinfo("Delete All", "No events to delete")
            return

        count = len(self.ctrl.steps)
        if messagebox.askyesno("Delete All Events",
                              f"Are you sure you want to delete all {count} events?\n\nThis cannot be undone!"):
            self.ctrl.steps.clear()
            self._refresh_events_list()
            self.log(f"🗑️ Deleted all {count} events")
            print(f"[APP] Deleted all {count} events")

    def duplicate_selected(self):
        """Duplicate selected steps"""
        sel = list(self.tree.selection())
        if not sel:
            messagebox.showinfo("Duplicate", "Please select events to duplicate")
            return

        indices = sorted([int(item.split('_')[1]) for item in sel])

        # Duplicate steps (insert after last selected)
        insert_pos = indices[-1] + 1
        duplicated = []

        for idx in indices:
            original = self.ctrl.steps[idx]
            # Create copy with new timestamp
            duplicate = Step(
                kind=original.kind,
                args=original.args.copy(),
                timestamp=time.time()
            )
            duplicated.append(duplicate)

        # Insert all duplicates
        for i, dup in enumerate(duplicated):
            self.ctrl.steps.insert(insert_pos + i, dup)

        self._refresh_events_list()
        self.log(f"📋 Duplicated {len(duplicated)} events")
        print(f"[APP] Duplicated {len(duplicated)} events")

        # Select the duplicated items
        for i in range(len(duplicated)):
            self.tree.selection_add(f'step_{insert_pos + i}')

    def show_logs(self):
        print("[APP] Opening logs window")
        LogsWindow(self, self.log_text)

    def new_task(self):
        print("[APP] New task requested")
        if messagebox.askyesno("New Task", "Clear all steps and start new task?"):
            self.ctrl.steps.clear()
            self._refresh_events_list()
            self.log("📄 New task created")
            print("[APP] Task cleared")

    def save_json(self):
        print("[APP] Save task dialog opened")
        fp = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[["JSON Task Files","*.json"], ["All Files","*.*"]],
            initialdir=os.getcwd()
        )
        if not fp:
            print("[APP] Save cancelled")
            return
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(self.ctrl.to_json())
        self.log(f"💾 Saved: {fp}")
        print(f"[APP] Task saved to {fp}")
        self.refresh_files_list()

    def load_json(self):
        print("[APP] Load task dialog opened")
        fp = filedialog.askopenfilename(
            filetypes=[["JSON Task Files","*.json"], ["All Files","*.*"]],
            initialdir=os.getcwd()
        )
        if not fp:
            print("[APP] Load cancelled")
            return
        with open(fp, 'r', encoding='utf-8') as f:
            self.ctrl.load_json(f.read())
        self._refresh_events_list()
        self.log(f"📂 Loaded: {fp}")
        print(f"[APP] Task loaded from {fp}")

        if self.ctrl.schedule_config.enabled:
            sch = self.ctrl.schedule_config
            info = []
            if sch.days:
                info.append(f"Days: {', '.join(sorted(sch.days))}")
            if sch.time_interval_enabled:
                info.append(f"Time: {sch.from_time}-{sch.to_time}")
            self.log(f"📅 Schedule: {' | '.join(info)}")
            print(f"[APP] Schedule loaded: {info}")

    def refresh_files_list(self):
        print("[APP] Refreshing files list")
        self.files_list.delete(0, 'end')
        count = 0
        for f in os.listdir('.'):
            if f.endswith('.json'):
                self.files_list.insert('end', f)
                count += 1
        print(f"[APP] Found {count} JSON files")

    def load_from_list(self):
        sel = self.files_list.curselection()
        if not sel:
            print("[APP] No file selected")
            return
        filename = self.files_list.get(sel[0])
        print(f"[APP] Loading from list: {filename}")
        with open(filename, 'r', encoding='utf-8') as f:
            self.ctrl.load_json(f.read())
        self._refresh_events_list()
        self.log(f"📂 Loaded: {filename}")

    def delete_task_file(self):
        sel = self.files_list.curselection()
        if not sel:
            return
        filename = self.files_list.get(sel[0])
        print(f"[APP] Delete file requested: {filename}")
        if messagebox.askyesno("Delete", f"Delete {filename}?"):
            os.remove(filename)
            self.refresh_files_list()
            self.log(f"🗑 Deleted: {filename}")
            print(f"[APP] File deleted: {filename}")

    def show_schedule_settings(self):
        print("[APP] Opening schedule settings...")
        dialog = ScheduleDialog(self, self.ctrl.schedule_config)
        self.wait_window(dialog)

        if dialog.result:
            self.ctrl.schedule_config = dialog.result
            if self.ctrl.schedule_config.enabled:
                info = []
                if self.ctrl.schedule_config.days:
                    info.append(f"Days: {', '.join(sorted(self.ctrl.schedule_config.days))}")
                if self.ctrl.schedule_config.time_interval_enabled:
                    info.append(f"{self.ctrl.schedule_config.from_time}-{self.ctrl.schedule_config.to_time}")
                self.log(f"📅 Schedule updated: {' | '.join(info)}")
                print(f"[APP] Schedule saved: {info}")

    def toggle_mini_mode(self):
        enabled = self.mini_mode_var.get()
        print(f"[APP] Mini mode toggled: {enabled}")

        if enabled:
            # Activare Mini Mode
            if not self.mini_window or not self.mini_window.winfo_exists():
                # Iconify main window FIRST
                self.iconify()
                print("[APP] Main window iconified")

                # Small delay to ensure main window is minimized
                self.after(200, lambda: self._create_mini_window())
        else:
            # Dezactivare Mini Mode
            if self.mini_window and self.mini_window.winfo_exists():
                self.mini_window.destroy()
                self.mini_window = None
                print("[MINI] Mini window destroyed")

            # Restore main window
            self.deiconify()
            self.lift()
            self.focus_force()
            print("[APP] Main window restored")
            self.log("🔼 Mini Mode deactivated")

    def _create_mini_window(self):
        self.mini_window = MiniModeWindow(self, self.ctrl)
        self.log("🔽 Mini Mode activated")
        print("[APP] Mini window created")

    def show_about(self):
        print("[APP] About dialog opened")
        messagebox.showinfo("About BEBE Task Recorder",
            "BEBE Task Recorder v5.3\n\n"
            "Advanced task automation and recording tool\n"
            "with hotkeys, scheduling, and playback control.\n\n"
            "© 2025 - Created for workflow automation")

    def log(self, msg: str):
        ts = time.strftime('%H:%M:%S')
        self.log_text.insert('end', f"[{ts}] {msg}\n")
        self.log_text.see('end')

if __name__ == '__main__':
    try:
        print("\n" + "="*60)
        print("BEBE Task Recorder v5.3 Starting...")
        print("="*60 + "\n")

        app = App()
        app.mainloop()
    except Exception as e:
        print(f"\n[ERROR] Application crashed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n[APP] Cleaning up...")
        keyboard.unhook_all()
        print("[APP] Shutdown complete")